%---------------------------------------------------------------------------
% function imIcon = ThumbCrop_Demo(filename, iFigure)
%   filename    : the file name of the original image
%   iFigure     : the figure #, use the figure window to display test result
%---------------------------------------------------------------------------
function imIcon = ThumbCrop_Demo(filename, iFigure)

im = imread(filename);

sNew=strtok(filename,'.');  

%-- Calculate contrast features
[imIContr, imCContr, imOContr, imSaliency] = CompSaliencyMap(im);

%-- Postprocessing saliency map, using distances to center as weights
imSaliencyEx = PostProcesSaliencyMap(imSaliency);

%-- Search for the cutting area
[XRange, YRange] = GetClipRegion_Heuristic(imSaliencyEx, 0.8);
%[XRange, YRange] = GetClipRegion(imSaliencyEx, 0.7)
imIconSaliency = imSaliencyEx(YRange(1):YRange(2),XRange(1):XRange(2),:);


%-- Cut the image and get the icon
XRange = XRange * 8;
YRange = YRange * 8;
sz = size(im);
XRange(1)=max(XRange(1),1); XRange(2)=min(XRange(2),sz(2));
YRange(1)=max(YRange(1),1); YRange(2)=min(YRange(2),sz(1));
imIcon = im( YRange(1):YRange(2), XRange(1):XRange(2), :);


%-- Demo output results
figure(iFigure); clf;
subplot(2,2,1);     imshow(im);             title 'Original'
subplot(2,2,2);     imshow(imIcon);         title 'Clipped Icon'
subplot(2,2,3);     imshow(imSaliencyEx);   title 'Postprocessed Saliency Map'
subplot(2,2,4);     imshow(imIconSaliency);     title 'Clipped Saliency Map'


    sNew=strtok(filename,'.');
    sMX=strcat(sNew,'_IntenContr.dt');
    SaveMatrix(imIContr,sMX);
    sMX=strcat(sNew,'_ColorContr.dt');
    SaveMatrix(imCContr,sMX);
    sMX=strcat(sNew,'_OrienContr.dt');
    SaveMatrix(imOContr,sMX);
    sMX=strcat(sNew,'_SaliencyContr.dt');
    SaveMatrix(imSaliency,sMX);

    sIcon = strcat( filename, '_icon.jpg');
    imwrite(imIcon, sIcon, 'jpeg');
    sIconS = strcat( filename, '_iconSaliency.jpg');
    imwrite(imIconSaliency, sIconS, 'jpeg');
    sSa = strcat( filename, '_Saliency.jpg');
    imwrite(imSaliency, sSa, 'jpeg');   
    sSa = strcat( filename, '_SaliencyEx.jpg');
    imwrite(imSaliencyEx, sSa, 'jpeg');   

return;