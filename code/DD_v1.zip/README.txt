IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING

By downloading, copying, installing or using the code, 
you agree with the following license claims:

COPYRIGHT (C) 2006, 2007, HAIBIN LING AND KAZUNORI OKADA, ALL RIGHTS RESERVED.

REDISTRIBUTION AND USE IN SOURCE AND BINARY FORMS, WITH OR WITHOUT MODIFICATION,
ARE PERMITTED FOR NON-PROFIT RESEARCH USE ONLY, PROVIDED THAT THE FOLLOWING 
CONDITIONS ARE MET:

REDISTRIBUTION'S OF SOURCE CODE MUST RETAIN THE ABOVE COPYRIGHT NOTICE,
THIS LIST OF CONDITIONS AND THE FOLLOWING DISCLAIMER.

REDISTRIBUTION'S IN BINARY FORM MUST REPRODUCE THE ABOVE COPYRIGHT NOTICE,
THIS LIST OF CONDITIONS AND THE FOLLOWING DISCLAIMER IN THE DOCUMENTATION
AND/OR OTHER MATERIALS PROVIDED WITH THE DISTRIBUTION.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT 
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. 
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 

If you do not agree to this license agreement, 
do not download, install, copy or use the software. 

------------------------------------------------------------------------------------------------------
This code implements the diffusion-based distance algorithm published in the following paper

	H. Ling and K. Okada, 
	Diffusion Distance for Histogram Comparison,
	IEEE Conference on Computer Vision and Pattern Recognition (CVPR), 
	Vol. I, pp. 246-253, 2006. 

This code is a RE-IMPLEMENTATION of the diffusion-based distance according to the above paper. 
	There is no guarantee of exact reproduction of the experimental results reported in the paper. 
	In addition, the method is licensed by 
		
	Siemens Corporate Research, Inc.
	755 College Road East
	Princeton, NJ 08540-6632
	Telephone: (609) 734-6500
	Fax: (609) 734-6565

	The usage of this code is restricted for non-profit research usage only and
	using of the code is at the user's risk.

------------------------------------------------------------------------------------------------------
NOTES:
1. Histogram matrices are assumed to be arranged in the "matlab" style, i.e, the [i,j,k]-th element is 
	located in the position
		i*(n2*n3) + j*(n3) + k

2. The example usage of the code is demonstrated in 
		dd_test.cpp

Author Contact Information:
	Haibin Ling (hbling at cs dot ucla dot edu)
	Kazunori Okada (kazokada at sfsu dot edu)
	09/23/07

