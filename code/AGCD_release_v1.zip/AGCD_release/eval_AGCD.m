function hyp = eval_AGCD(weights, learners,D,nh)

if (nargin < 4)
nh = length(weights);
end
hyp = zeros(size(D,1),1);

for i = 1 : nh
   
    hyp = hyp + weights(i)*eval_stump(learners{i},D);
    
end