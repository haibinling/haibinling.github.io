%Boosting with Competing factor 
%weak learner are decision stumps
%greedy coordinate descent algorithm

function [weights_c, learners_c,weights_a,learners_a,hist_energy]= AGCD(D, Yt, A, Ya, param,weights_c_old, learners_c_old,weights_a_old,learners_a_old)

%param structure: param.lambda  param.MaxIter
%D: nD*dim target task 
%Yt: nD*1 target label
%A: nA*dim auxiliary task
%Ya: nA auxliary label
MaxIter = param.MaxIter;
weights_c = zeros(MaxIter,1); learners_c =cell(MaxIter,1); 
weights_a = zeros(MaxIter,1); learners_a = cell(MaxIter,1);
hist_energy = zeros(1,MaxIter); 
MaxIter = param.MaxIter;

d = size(D,2);
q_c = zeros(d,1);
q_a  = q_c;

na = size(A,1); distr_a = ones(na,1)/na;final_hypo_a = zeros(na,1);
nd = size(D,1); distr_c = ones(nd,1)/nd;final_hypo_c = zeros(nd,1);

if(nargin > 5) %have old weak learners;
   oldIter_c = length(weights_c_old);
   oldIter_a = length(weights_a_old);
   
   for i = 1 : oldIter_c
      q_c = update(q_c,weights_c_old(i), learners_c_old{i});
   end
   
   for i = 1 : oldIter_a
      q_a = update(q_a,weights_a_old(i), learners_a_old{i});
   end
   final_hypo_c = 	eval_XBoost(weights_c_old, learners_c_old,D);	
   final_hypo_a = 	eval_XBoost(weights_a_old, learners_a_old,A);
   
   distr_c = exp(- (Yt .* final_hypo_c));  distr_c = distr_c/sum(distr_c);
   distr_a = exp(- (Ya .* final_hypo_a)); distr_a = distr_a/sum(distr_a);

end

for iter = 1 : MaxIter
    
    disp(['XBoosting Iteration: ',num2str(iter),'---beta: ',num2str(param.beta)])
    %alternative optimization
    % for task c; 
    [weights_c(iter),learners_c{iter} ]=  greedysearch_AGCD(D, Yt, distr_c,q_a,param,0);
    
    if(param.stepsize == 0) %greedy search
     weights_c(iter)= update_weight(D,Yt,distr_c, q_c,q_a, learners_c{iter},param);
    end
   
    %update q_c;
    q_c = update(q_c,weights_c(iter), learners_c{iter});
    
    step_out =weights_c(iter) *eval_stump(learners_c{iter},D);
    
    distr_c = distr_c.*exp(-Yt.*step_out);
    
    final_hypo_c =  final_hypo_c + step_out; 
    %for task a;
    if(~isempty(A))
    [weights_a(iter),learners_a{iter} ]=  greedysearch_AGCD(A, Ya, distr_a,q_c,param,1);
    
    if(param.stepsize == 0)
    weights_a(iter)= update_weight(A,Ya,distr_a, q_a,q_c, learners_a{iter},param);
    end
    
    %update q_a;
    q_a = update(q_a,weights_a(iter),learners_a{iter});
    
    step_out = weights_a(iter)*eval_stump(learners_a{iter},A);
    
    distr_a = distr_a.*exp(-Ya.*step_out);
    
    final_hypo_a = final_hypo_a + step_out;
    
    hist_energy(iter) = sum(exp(-Yt.*final_hypo_c)) + sum(exp(-Ya.*final_hypo_a)) + param.lambda*q_c'*q_a;
    end
end

if(nargin > 5)
	weights_c = [weights_c_old; weights_c];
	learners_c = [learners_c_old;learners_c];
	weights_a = [weights_a_old; weights_a];
	learners_a= [learners_a_old;learners_a];
end

function q = update(q, weight, learner)
%        w = learner.stepsize;
       ind = learner.ind;
       q(ind) = q(ind) + weight;
end

 function weight = update_weight(D,Yt,distr, Q1,Q0,learners,param)
        %weight = (W1-W0-2*lambda*Q1(k)*Q0(k))/(W1+W0+2*lambda*Q0(k));
        lambda = param.lambda;
        minstep = param.minstep;
       k = learners.ind;
       hyp_cur  =  eval_stump(learners,D);
       acc = hyp_cur.*Yt;
       W1 = sum(distr(find(acc>0)));
       W0 = sum(distr(find(acc<0)));
       
       weight = (W1-W0-2*lambda*Q1(k)*Q0(k))/(W1+W0+2*lambda*Q0(k));
       weight = max(weight,minstep);
    
  end

end