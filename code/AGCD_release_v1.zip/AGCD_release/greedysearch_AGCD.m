
% ----------------------------------------------
% build a stump from each component and return the best

function [weight, learner] = greedysearch_AGCD(X,y,w, reg,param,flag)

lambda = param.lambda;
if(flag)
    beta = param.beta;
else
    beta = 1;
end
d = size(X,2);
w = w/sum(w); % normalized the weights (if not already)

stump = cell(d,1); 
agree = zeros(d,1);
%  tic;
parfor i=1:d,
  stump{i} = build_onedim_stump(X(:,i),y,w);
  stump{i}.ind = i; 
  agree(i) = beta*stump{i}.agree - lambda*reg(i); % regularized agreement
end;

[~,ind] = max(agree);

learner = stump{ind(1)}; % return the best stump 


if(param.stepsize) 
    weight = param.stepsize; %fixed small stepsize
else
    %greedy stepsize;
    weight = 0;
end
    
    
end

 
