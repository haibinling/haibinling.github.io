%%
% TGPR: Transfer Learning Based Visual Tracking with Gaussian Process Regression
%
% Code to accompany the paper:
%   Transfer Learning Based Visual Tracking with Gaussian Process Regression
%   Jin Gao, Haibin Ling, Weiming Hu, Junliang Xing
%   ECCV2014, Part III, LNC 8691, pp. 188-203, 2014
%
% Copyright (C) 2014 Jin Gao
%
% This file is part of TGPR.

%% This code is to accompany the TGPR's evaluation on the CVPR2013 Visual Tracker Benchmark[1]
%%(https://sites.google.com/site/trackerbenchmark/benchmarks/v10).



[1]Yi Wu, Jongwoo Lim, and Ming-Hsuan Yang, ��Online Object Tracking: A Benchmark,�� 
   in IEEE Conference on Computer Vision and Pattern Recognition (CVPR), 2013. 
