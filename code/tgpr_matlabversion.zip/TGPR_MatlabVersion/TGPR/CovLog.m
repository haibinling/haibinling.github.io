function [ RM ] = CovLog( X,GridNum )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
GridCovArray=cell(GridNum);
RM = [];
[d,n] = size(X);
sz = [64 64];

for jj = 1:1:n
    GridCovArray=ImageGrid(255*reshape(X(:,jj),[sz(1),sz(2)]),GridNum,GridCovArray);
end

for m_ = 1:1:GridNum(1)
    for n_ = 1:1:GridNum(2)
        RM = cat(1,RM,GridCovArray{m_,n_});
        GridCovArray{m_,n_} = [];
    end
end
end

