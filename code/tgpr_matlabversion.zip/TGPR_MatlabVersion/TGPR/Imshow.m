function [] = Imshow(X)
[m_ n_] = size(X);
% for i = 1:1:n_
%     x = reshape(X(:,i),[32,32]);
%     figure(4);
%     imshow(x);
% end
if (n_ < m_)
    Y = zeros(m_,m_-n_);
    X = cat(2,X,Y);
end
k = floor(sqrt(m_));
A = zeros(m_,m_);
for i = 1:1:k
    for j = 1:1:k
        A((1+(i-1)*k):(i*k),(1+(j-1)*k):(j*k)) = reshape(X(:,(i-1)*k+j),[k,k]);
    end
end
imshow(A);
end