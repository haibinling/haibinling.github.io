function [ a ] = matrixlb( A )
% Upper triangular elements

yourWant = A(logical(triu(ones(size(A)))));
% triu(A)
a = yourWant; 

end

