%%
% TGPR: Transfer Learning Based Visual Tracking with Gaussian Process Regression
%
% Code to accompany the paper:
%   Transfer Learning Based Visual Tracking with Gaussian Process Regression
%   Jin Gao, Haibin Ling, Weiming Hu, Junliang Xing
%   ECCV2014, Part III, LNC 8691, pp. 188-203, 2014
%
% Copyright (C) 2014 Jin Gao
%
% This file is part of TGPR.

%% This script is to accompany the TGPR's evaluation on the CVPR2013 Visual Tracker Benchmark (Y. Wu et al, CVPR2013) 

function results=run_TGPR(seq, res_path, bSaveImage)

close all;

s_frames = seq.s_frames;

init = seq.init_rect; % init:(lefttop x, lefttop y, width, height) 
p = [init(1)+init(3)/2 init(2)+init(4)/2 init(3) init(4) 0];
opt = struct('numsample',300,'affsig',[init(3)/4,init(4)/4,.05,.00,.002,.000]); % particle number and affine transformation parameters
                                                 
%% Initialize tracker variables

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Set the grid cells
GridNum = [4 4];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

psize = [16*GridNum(1), 16*GridNum(2)]; % size of template 

count = seq.len;
im0 = imread(['../.' s_frames{1}]);
height = size(im0,1);
width = size(im0,2);
x = init(1);
y = init(2);
W = init(3);
H = init(4);

results = zeros(count, 4);

results(1, :) = [x y x+W y+H];

param0 = [p(1), p(2), p(3)/psize(1), p(5), p(4)/p(3), 0];

param0 = affparam2mat(param0);
if size(im0,3)==3
    grayframe = rgb2gray(im0);
else
    grayframe = im0;
end
frame = double(grayframe)/255; %

drawopt=[];
res = [];
param = [];
param.est = param0;
param.wimg = warpimg(frame, param0, psize);

% draw result
if bSaveImage
    drawopt = drawtrackresult([], 1, frame, psize, param.est'); 
    imwrite(frame2im(getframe(gcf)),sprintf('../.%s%04d.jpg',res_path, 1));
end

paramest = affparam2geom(param.est(:));

%%%%%%%
% Extend the image so that the partial disappearing out of view can be
% handled
largex = floor(width/2.0);
largey = floor(height/2.0);
param.est(1) = param.est(1) + largex;
param.est(2) = param.est(2) + largey;

frame = cat(1,frame,frame(size(frame,1)-largey:size(frame,1),:));
frame = cat(1,frame(1:largey,:),frame);
frame = cat(2,frame,frame(:,size(frame,2)-largex:size(frame,2)));
frame = cat(2,frame(:,1:largex),frame);
%%%%%%%

if ~exist('Wimgs') 
    Wimgs = [];  end             %store the samples with the extracted feature
if ~isfield(Wimgs,'aPosi')   
    Wimgs.aPosi = [];  end       %auxiliary positive
if ~isfield(Wimgs,'aNega')      
    Wimgs.aNega = [];  end       %auxiliary negative
if ~isfield(Wimgs,'tPosi')   
    Wimgs.tPosi = [];  end       %target positive
if ~isfield(Wimgs,'tNega')   
    Wimgs.tNega = [];  end       %target negative

if ~exist('WimgO') 
    WimgO = [];  end             %store a thumbnail for each sample
if ~isfield(WimgO,'aPosi')   
    WimgO.aPosi = [];  end       %auxiliary positive
if ~isfield(WimgO,'aNega')   
    WimgO.aNega = [];  end       %auxiliary negative
if ~isfield(WimgO,'tPosi')   
    WimgO.tPosi = [];  end       %target positive
if ~isfield(WimgO,'tNega')   
    WimgO.tNega = [];  end       %target negative

%%%%%%%
% the features of the whole image for covariance feature extraction of each sample
if ~exist('Interfrm') 
    Interfrm = [];  end
if ~isfield(Interfrm,'Intensity')
    Interfrm.Intensity = [];
end
if ~isfield(Interfrm,'Der_1x')
    Interfrm.Der_1x = [];
end
if ~isfield(Interfrm,'Der_1y')
    Interfrm.Der_1y = [];
end
if ~isfield(Interfrm,'GradMod')
    Interfrm.GradMod = [];
end
frmrig = 255*frame;
Sizefrm = size(frmrig);
[Interfrm.Intensity,Interfrm.Der_1x,Interfrm.Der_1y,Interfrm.GradMod]=GRCGnew(frmrig,Sizefrm(1),Sizefrm(2));
%%%%%%%

%%%%%%%%%%%%%%%
%Initial the sample sets from the first frame
%auxiliary positive
WimgO.aPosi = [WimgO.aPosi param.wimg(:)];
Wimgs.aPosi = [Wimgs.aPosi CovLognew(Interfrm,frame,affparam2geom(param.est(:)),GridNum)];

%auxiliary negative
B = cat(1,0,affparam2geom(param.est(:)));
paramN = cat(2,B(2:7)+[-B(4)*psize(1)/5 0 0 0 0 0]',B(2:7)+[B(4)*psize(1)/5 0 0 0 0 0]',B(2:7)+[0 -B(4)*psize(1)*B(6)/5 0 0 0 0]',B(2:7)+[0 B(4)*psize(1)*B(6)/5 0 0 0 0]');
wimgN = warpimg(frame, affparam2mat(paramN), psize);
wimgN = reshape(wimgN,[psize(1)*psize(2),4]);
Wimgs.aNega = [Wimgs.aNega CovLognew(Interfrm,frame,paramN,GridNum)];
WimgO.aNega = [WimgO.aNega wimgN];

%target positive
WimgO.tPosi = [WimgO.tPosi param.wimg(:)];
Wimgs.tPosi = [Wimgs.tPosi Wimgs.aPosi(:,1)];

%target negative
current_state = [B(2) B(3) B(4)*psize(1) B(4)*psize(1)*B(6)];
[targetN, paramN] = sampleImage(frame,current_state,psize,40);
Wimgs.tNega = CovLognew(Interfrm,frame,paramN,GridNum);
WimgO.tNega = targetN;

%buffer size
if ~exist('Num') 
    Num = [];  end
if ~isfield(Num,'aPosi')   
    Num.aPosi = 55;  end
if ~isfield(Num,'aNega')   
    Num.aNega = 220;  end
if ~isfield(Num,'tPosi')   
    Num.tPosi = 12;  end
if ~isfield(Num,'tNega')   
    Num.tNega = 64;  end

%% Run the TGPR algorithm
opt_reser = opt;
res = [res; affparam2mat(paramest(:))'];
duration = 0;
for t=2:seq.len
    im0 = imread(['../.' s_frames{t}]);
    if size(im0,3)==3
        grayframe = rgb2gray(im0);
    else
        grayframe = im0;
    end
    frame = double(grayframe)/255; %
    tic
    frame = cat(1,frame,frame(size(frame,1)-largey:size(frame,1),:));
    frame = cat(1,frame(1:largey,:),frame);
    frame = cat(2,frame,frame(:,size(frame,2)-largex:size(frame,2)));
    frame = cat(2,frame(:,1:largex),frame);

	% Apply the TGPR algorithm to move (x,y)
	% to the target location in the next frame.
%     debug5 = t
    [param, opt, Wimgs, WimgO] = ...
      TGPR(frame, param, opt, Wimgs, WimgO, Num, t, GridNum, psize, W, H);
    paramest = affparam2geom(param.est(:));
    W = paramest(3)*psize(1);
    H = paramest(5)*W;
    x = paramest(1) - largex - W/2;
    y = paramest(2) - largey - H/2;
    duration = duration + toc;
	results(t, :) = [x, y, x+W, y+H];
    
    paramest(1) = paramest(1) - largex;
    paramest(2) = paramest(2) - largey;
%     t
%     affparam2mat(paramest(:))'
    res = [res; affparam2mat(paramest(:))']; 
    frame = frame(largey+1:end-largey,largex+1:end-largex);
    %% draw result
    if bSaveImage
        drawopt = drawtrackresult(drawopt, t, frame, psize, res(end,:)'); % 
        imwrite(frame2im(getframe(gcf)),sprintf('../.%s%04d.jpg',res_path,t));  
    end
end          
    fps = (count-1)/duration;
    
    results.res=res;
    results.type='ivtAff';
    results.tmplsize = psize;
    results.fps = fps;
    disp(['fps: ' num2str(results.fps)])
    
end