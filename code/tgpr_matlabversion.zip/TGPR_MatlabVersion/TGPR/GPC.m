function C=GPC(I,Pos1,Pos2)
Size = size(I);
[Coor_x,Coor_y,Intensity,Der_1x,Der_1y,GradMod]=GRCG(I,Size(1),Size(2));
C=Covariance(Coor_x,Coor_y,Intensity,Der_1x,Der_1y,GradMod,Pos1,Pos2);
end



% [Coor_x,Coor_y,Intensity,Der_1x,Der_1y,Der_2x,Der_2y]=GRCG(I,Size(1),Size(2));
% [Q1,Q2,Q3,Q4,P1,P2,P3,P4]=GIQ(Coor_x,Coor_y,Intensity,Der_1x,Der_1y,Der_2x,Der_2y,[Pos1 Pos2]);
% tmp=(P1+P2-P3-P4);
% n=(Pos2(1)-Pos1(1))*(Pos2(2)-Pos1(2));
% tmp=(tmp*tmp')/n;
% C=Q1+Q2-Q3-Q4-tmp;
% C=C/(n-1);
