function GridCovArray=ImageGrid(I,GridNum,GridCovArray)
%tic;
sz=[size(I,1) size(I,2)];%[28 28]
GridSize=floor(sz./GridNum);%[7 7]
%GridCovArray=cell(GridNum(1),GridNum(2));
for i=1:GridNum(1)%1~4
    Idx=(i-1)*GridSize(1)+[1:GridSize(1)];
    for j=1:GridNum(2)
        Idy=(j-1)*GridSize(2)+[1:GridSize(2)];
        GridCovArray{i,j}=[GridCovArray{i,j} ...
            matrixlb(logm(eye(6)*1e-5+GPC(I(Idx,Idy),[1 1],[GridSize(1)-2 GridSize(2)-2])))];
        %GPC(I(Idx,Idy),[1 1],GridSize-2); %reshape(GPC(I(Idx,Idy),[1 1],GridSize),36,1);        
    end
end
%toc;
end


