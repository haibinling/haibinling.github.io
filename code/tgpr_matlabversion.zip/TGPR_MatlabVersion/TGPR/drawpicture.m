function drawopt = drawpicture(f,frame, parameter,sz)
figure(1)
imshow(frame);
hold on
%sz = size(template);
%text(10,28, ['#',num2str(f)], 'Color','y', 'FontWeight','bold', 'FontSize',24);
n = size(parameter,2);

drawbox(sz, parameter(:,1)', 'LineStyle', '--', 'Color','r', 'LineWidth',3);
drawbox(sz, parameter(:,2)', 'Color','b', 'LineWidth',3);
% drawbox(sz, parameter(:,3)', 'Color','c', 'LineWidth',3);
% drawbox(sz, parameter(:,4)', 'Color',[0.6,0.2,0], 'LineWidth',3);
% drawbox(sz, parameter(:,5)', 'Color','g', 'LineWidth',3);
% drawbox(sz, parameter(:,6)', 'Color',[0.75,0.75,0], 'LineWidth',3);
% drawbox(sz, parameter(:,7)', 'Color','y', 'LineWidth',3);
% drawbox(sz, parameter(:,8)', 'Color','b', 'LineWidth',3);
text(5,14, ['Frame' num2str(f)], 'Color','y', 'FontWeight','bold', 'FontSize',18);
% drawbox(sz, parameter(:,1)', 'Color','r', 'LineWidth',3);
% drawbox(sz, parameter(:,2)', 'Color','b', 'LineWidth',3);

drawopt = 1;