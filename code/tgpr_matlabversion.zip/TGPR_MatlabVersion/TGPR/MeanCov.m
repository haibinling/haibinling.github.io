function [ C ] = MeanCov( C_sets )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
[d,n] = size(C_sets);
[x,y] = size(C_sets{1,1});
% C = C_sets{d,1};
% yipsllon = 1e-10;
% flag = 1;
% sum = zeros(x,y);
% time = 20;
% while flag >= yipsllon
%     for t = 1:1:n
%         c_t = logm(inv(C)*C_sets{d,t});
%         sum = sum + c_t;
%     end
%     deltC = expm(sum./n);
%     C = C*deltC;
%     flag = norm(logm(deltC),'fro');
%     if(time>0)
%         time = time - 1;
%     else
%         break;
%     end
% end
sum = zeros(x,y);
for t = 1:1:n
    c_t = logm(C_sets{d,t});
    sum = sum + c_t;
end
C = expm(sum./n);
end

