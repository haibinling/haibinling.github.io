#include "mex.h"
#include <math.h>
#include "memory.h"
#include "stdio.h"
#define Dim 6

inline void GMean(double *pImg[], const int * dimz, double *P1, double *P2, double *pData)
{
//	double *pData=new double[Dim];
	for (int d=0;d<Dim;d++)
	{
		double tmp=0.0;
		for (int i=(int)P1[0]-1;i<=(int)P2[0]-1;i++)
		{
			for (int j=(int)P1[1]-1;j<=(int)P2[1]-1;j++)
			{
				tmp+=pImg[d][i*dimz[1]+j];
			}
		}
		pData[d]=tmp/((P2[0]-P1[0]+1)*((P2[1]-P1[1]+1)));
		//if(d<2)
		//	printf("%5f  ",pData[d]);
	}
//	return pData;
}


inline void VecProduct(double *a, double *pData)
{
	for (int i=0;i<Dim;i++)
    {
		for (int j=0;j<Dim;j++)
		{
			pData[i*Dim+j]+=a[i]*a[j];
		    //printf("%3f  ",pData[i*Dim+j]);
		}
		//printf("\n");
    }
}


//inline double * VecAdd(double *a,double *b)
//{
//    double *pData=new double[Dim*Dim];
//	for (int i=0;i<Dim*Dim;i++)
//    {
//	    pData[i]=a[i]+b[i];
//   }
//    return pData;
//}

inline void VecAdd(double *a,double *b)
{
//    double *pData=new double[Dim*Dim];
	for (int i=0;i<Dim*Dim;i++)
    {
	    b[i]=a[i]+b[i];
    }
//    return pData;
//    delete []pData;
}


inline void VecSub(double *a,double *b)
{
	for (int i=0;i<Dim;i++)
    {
	    //printf("ǰ%f  \n",a[i]);
        a[i]=a[i]-b[i];
        //printf("��%f  \n",a[i]);
    }
}


inline void ConstProduct(double *a,double lamda)
{
	for (int i=0;i<Dim*Dim;i++)
    {
		//printf("ǰ%f  \n",a[i]);
        a[i]=a[i]*lamda;
       //printf("��%f  \n",a[i]);
    }
}


inline void VecFlat(double *a,double *b)
{
	int index=0;
	for (int i=0;i<Dim;i++)
    {
		for (int j=i;j<Dim;j++)
		{
			if(j==i)
			{
				b[index]=a[i*Dim+j];
			}
			else
			{
                b[index]=sqrt(2.0)*a[i*Dim+j];
				//printf("%f \n",b[index]);
			}
			index++;
		}
	}
	
}


//-----------------------------------------------------------------------------

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
  const int CP_1=Dim;
  const int CP_2=Dim+1;
  double *P1 = mxGetPr(prhs[CP_1]);
  double *P2 = mxGetPr(prhs[CP_2]);

  const int *dimz = mxGetDimensions(prhs[0]);
  mxArray *F=NULL,*FVec=NULL;
  F = plhs[0] = mxCreateDoubleMatrix(Dim,Dim, mxREAL);
  //FVec = plhs[1] = mxCreateDoubleMatrix((Dim*(Dim+1))/2,1, mxREAL);
  
  const mxArray  *Q[Dim];
  double *InData[Dim];
  double *RM=new double[Dim];

    
  for (int ii=0;ii<Dim;ii++)
  {
     Q[ii] = prhs[ii];
	 InData[ii]=mxGetPr(Q[ii]);
  }
  //printf("%d   %d \n",dimz[0],dimz[1]);
  
  GMean(InData,dimz,P1,P2,RM);
  
  //for(int jj=0;jj<Dim;jj++)
  //{
  //    printf("%6f   \n",RM[jj]);
  //}
  
  double *Cov=mxGetPr(F);
  //printf("%d \n",mxGetNumberOfElements(F));
  for(int kk=0;kk<Dim*Dim;kk++)
  {
      Cov[kk]=0.0;
  }
 
  for (int i=(int)P1[0]-1;i<=(int)P2[0]-1;i++)
  {
	  for (int j=(int)P1[1]-1;j<=(int)P2[1]-1;j++)
	  {
          double *tmp=new double[Dim];
		  for (int d=0;d<Dim;d++)
          {
			  tmp[d]=InData[d][i*dimz[1]+j]-RM[d];
              //printf("%3f  ",tmp[d]);
          }
		  //VecSub(tmp,RM);
          VecProduct(tmp,Cov);
		  delete []tmp;
	  }
	  //printf("\n\n");
  }
  double lamda=1.0/((P2[0]-P1[0]+1)*((P2[1]-P1[1]+1)));
  //for(int jj=0;jj<Dim*Dim;jj++)
  //{
   //   printf("%6f   ",Cov[jj]);
 // }
  ConstProduct(Cov,lamda);
  //double *vec=mxGetPr(FVec);
  //VecFlat(Cov,vec);
  delete []RM;
}
  




  

  
  
  
  
