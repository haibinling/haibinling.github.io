function [samples_observation, paramN2] = sampleImage(image,state,psize,neg_num)

sz = psize;
N = sz(1)*sz(2);
frm = image;
B = [state(1,1) state(1,2) state(1,3)/sz(1) 0 state(1,4)/state(1,3) 0];

x = state(1,1);
y = state(1,2);
w = state(1,3);
h = state(1,4);

nstep = floor(neg_num/8);
stepw = w/(2.5*nstep);
steph = h/(2.5*nstep);
t = nstep:1:(nstep+nstep-1);
d1 = stepw*[t -t];
param1 = cat(1,d1,zeros(5,size(d1,2)));
d2 = steph*[t -t];
param2 = cat(1,0*d2,d2,zeros(4,size(d2,2)));

param3 = cat(1,d1,d2,zeros(4,size(d1,2)));

param4 = cat(1,d1,-d2,zeros(4,size(d1,2)));

paramN2 = [];
paramN = cat(2,param1,param2,param3,param4);

paramN = repmat(B',[1,size(paramN,2)]) + paramN;

halfw_partical = paramN(3,:)*sz(1)*0.5;
halfh_partical = paramN(5,:).*halfw_partical;
x1_partical = paramN(1,:) - halfw_partical;
y1_partical = paramN(2,:) - halfh_partical;
x2_partical = paramN(1,:) + halfw_partical;
y2_partical = paramN(2,:) + halfh_partical;
x1_edge = floor(0.25*size(frm,2));
x2_edge = floor(0.75*size(frm,2));
y1_edge = floor(0.25*size(frm,1));
y2_edge = floor(0.75*size(frm,1));
for i = 1:1:size(paramN,2)
    if (x1_partical(i) < 3 || x1_partical(i) > x2_edge || y1_partical(i) < 3 || y1_partical(i) > y2_edge || x2_partical(i) > (size(frm,2)-2) || x2_partical(i) < x1_edge || y2_partical(i) > (size(frm,1)-2) || y2_partical(i) < y1_edge)
        % Excluding the samples not in the view
    else
        paramN2 = [paramN2 paramN(:,i)];
    end
end

wimgN = warpimg(image, affparam2mat(paramN2), sz);

samples_observation = reshape(wimgN,[N,size(paramN2,2)]);
end