function [param, opt, Wimgs, WimgO] ...
    = TGPR(frm, param, opt, Wimgs, WimgO, Num, f, dgridNum, psize, Width, Height)
%%
% TGPR: Transfer Learning Based Visual Tracking with Gaussian Process Regression
%
% Code to accompany the paper:
%   Transfer Learning Based Visual Tracking with Gaussian Process Regression
%   Jin Gao, Haibin Ling, Weiming Hu, Junliang Xing
%   ECCV2014, Part III, LNC 8691, pp. 188-203, 2014
%
% Copyright (C) 2014 Jin Gao
%
% This file is part of TGPR.

delete = 2;  %parameter for accompany with the intervals which the auxiliary samples collected at; delete the coincide samples in the auxiliary and target samples
dgrid = 2.5; %parameter for auxiliary negative samples collection

n = opt.numsample;

sz = psize;
N = sz(1)*sz(2);

if ~isfield(param,'reser')
    param.reser = param.est;
end

% param.param = repmat(affparam2geom(param.reser(:)), [1,n]);
% 
% param.param = param.param + randn(6,n).*repmat(opt.affsig(:),[1,n]);
% indicate = ones(1,size(param.param,2))*100;
% for i = 1:1:size(param.param,2)
%     if (param.param(1,i) < floor(0.30*size(frm,2)) || param.param(1,i) > floor(0.70*size(frm,2)) || param.param(2,i) < floor(0.30*size(frm,1)) || param.param(2,i) > floor(0.70*size(frm,1)))
%     %if (param.param(1,i) < floor(0.32*size(frm,2)) || param.param(1,i) > floor(0.68*size(frm,2)))
%         indicate(i) = -100;  % Excluding the samples not in the view
%     end
% end

paramparam = repmat(affparam2geom(param.reser(:)), [1,n]);
param.param = [];
paramparam = paramparam + randn(6,n).*repmat(opt.affsig(:),[1,n]);
halfw_partical = paramparam(3,:)*sz(1)*0.5;
halfh_partical = paramparam(5,:).*halfw_partical;
x1_partical = paramparam(1,:) - halfw_partical;
y1_partical = paramparam(2,:) - halfh_partical;
x2_partical = paramparam(1,:) + halfw_partical;
y2_partical = paramparam(2,:) + halfh_partical;
x1_edge = floor(0.25*size(frm,2));
x2_edge = floor(0.75*size(frm,2));
y1_edge = floor(0.25*size(frm,1));
y2_edge = floor(0.75*size(frm,1));
for i = 1:1:size(paramparam,2)
    if (x1_partical(i) < 3 || x1_partical(i) > x2_edge || y1_partical(i) < 3 || y1_partical(i) > y2_edge || x2_partical(i) > (size(frm,2)-2) || x2_partical(i) < x1_edge || y2_partical(i) > (size(frm,1)-2) || y2_partical(i) < y1_edge || halfw_partical(i) < 5 || halfh_partical(i) < 5)
        % Excluding the samples not in the view
    else
        param.param = [param.param paramparam(:,i)];
    end
end
n = size(param.param,2);

if ~exist('Interfrm') 
    Interfrm = [];  end
if ~isfield(Interfrm,'Intensity')
    Interfrm.Intensity = [];
end
if ~isfield(Interfrm,'Der_1x')
    Interfrm.Der_1x = [];
end
if ~isfield(Interfrm,'Der_1y')
    Interfrm.Der_1y = [];
end
if ~isfield(Interfrm,'GradMod')
    Interfrm.GradMod = [];
end
frmrig = 255*frm;
Sizefrm = size(frmrig);
[Interfrm.Intensity,Interfrm.Der_1x,Interfrm.Der_1y,Interfrm.GradMod]=GRCGnew(frmrig,Sizefrm(1),Sizefrm(2));

S = [];
pha = 3.9;

beta = 1;
sig = 1000;
r = 10.0;
eta = 0.2;

Cas = 0;
numI = 0;
pool = 20;
Fua = [];
Fut = [];

if ((size(Wimgs.aPosi,2) +  size(Wimgs.aNega,2)) < 30)    % only use the target classifier
    [W,Pk,Simila,Sknn,S] = ContextLogSimi(dgridNum,Interfrm,frm,cat(2,Wimgs.tPosi,Wimgs.tNega),param.param,50,pha,S); % construct kernel
    W = Pk;
    D = diag(ones(size(sum(W,2)))./sum(W,2));
    delta = inv(D) - W;
    Mdelta = beta*(delta + eye(size(delta,2))*(1/(sig^2)));
    G = inv(Mdelta);
    %G = W + eye(size(W,2))*(1/(sig^2));
    tP = size(Wimgs.tPosi,2);
    tN = size(Wimgs.tNega,2);
    invGLL = inv(G(1:tP+tN,1:tP+tN));
    Z = cat(2,ones(1,tP),-1*ones(1,tN));
    Z = Z';
    YL = Z;
    for iteration = 1:1:40
        pai = ones(size(YL))./(ones(size(YL)) + exp(-2*r*YL));
        dq1q2 = r*(Z - ones(size(Z))) + 2*r*(ones(size(pai)) - pai) - G(1:tP+tN,1:tP+tN)\YL;
        Q = 4*r^2*diag(pai.*(ones(size(pai)) - pai));
        H = -invGLL-Q;
        YL = YL - eta*(H\dq1q2);
    end
    terminate = n-1;
    YU = G(end-terminate:1:end,1:1:end-terminate-1)*(G(1:tP+tN,1:tP+tN)\YL);
%     YU = G(end-terminate:1:end,1:1:end-terminate-1)*invGLL*YL;
%     YU = min(YU, indicate(:));
    [prob,IDX] = sort(YU,'descend');
    
    Fu = IDX(1:5);
    flag = 0;
else  % use the transfer learning based GPR
    aP = size(Wimgs.aPosi(:,1:end-delete),2);
    aN = size(Wimgs.aNega(:,1:end-delete*4),2);
    tP = size(Wimgs.tPosi,2);
    tN = size(Wimgs.tNega,2);
    [W,Pk,Simila,Sknn,S] = ContextLogSimi(dgridNum,Interfrm,frm,cat(2,Wimgs.aPosi(:,1:end-delete),Wimgs.aNega(:,1:end-delete*4),Wimgs.tPosi,Wimgs.tNega),param.param,50,pha,S);
    W = Pk;
      
    D = diag(ones(size(sum(W,2)))./sum(W,2));
    delta = inv(D) - W;
    Mdelta = beta*(delta + eye(size(delta,2))*(1/(sig^2)));
    G = inv(Mdelta);
%     G = W + eye(size(W,2))*(1/(sig^2));
%     tP = size(Wimgs.tPosi,2);
%     tN = size(Wimgs.tNega,2);
    invGLL = inv(G(1:aP+aN+tP+tN,1:aP+aN+tP+tN));
    H11 = invGLL(1:aP+aN,1:aP+aN);
    H12 = invGLL(1:aP+aN,aP+aN+1:end);
    H21 = invGLL(aP+aN+1:end,1:aP+aN);
    H22 = invGLL(aP+aN+1:end,aP+aN+1:end);
    Z = cat(2,ones(1,aP),-1*ones(1,aN),ones(1,tP),-1*ones(1,tN));
    Z = Z';
    Ya = Z(1:aP+aN);
%     Yt = cat(2,ones(1,tP),-1*ones(1,tN)*(tP/tN));
%     Yt = Yt';
    Yt = Z(aP+aN+1:end);
    for iteration = 1:1:40
        pai = ones(size(Ya))./(ones(size(Ya)) + exp(-2*r*Ya));
        dq1q2 = r*(Z(1:aP+aN) - ones(size(Z(1:aP+aN)))) + 2*r*(ones(size(pai)) - pai) - H11*Ya - 0.5*H21'*Yt -0.5*H12*Yt;
        Q = 4*r^2*diag(pai.*(ones(size(pai)) - pai));
        H = -H11-Q;
        Ya = Ya - eta*(H\dq1q2);
    end
    terminate = n-1;
%     Yt = Z(aP+aN+1:end);
%     YU = G(end-terminate:1:end,1:1:end-terminate-1)*invGLL*[Ya' Yt']';
%     Fu = YU;

%%%%%%%
% auxiliary classifier
%     [Wa,Pka,Simila,Sknna,Sa] = ContextLogSimi(cat(2,Wimgs.aPosi(:,1:end-delete),Wimgs.aNega(:,1:end-delete*4),Unlabeled),50,pha,Sa);
    Wa = cat(1,cat(2,Pk(1:aP+aN,1:aP+aN),Pk(1:aP+aN,end-n+1:end)),cat(2,Pk(end-n+1:end,1:aP+aN),Pk(end-n+1:end,end-n+1:end)));
%     Wa = Pka;
    Da = diag(ones(size(sum(Wa,2)))./sum(Wa,2));
    deltaa = inv(Da) - Wa;
    Mdeltaa = beta*(deltaa + eye(size(deltaa,2))*(1/(sig^2)));
    Ga = inv(Mdeltaa);
%     invGLLa = inv(Ga(1:aP+aN,1:aP+aN));
    YUa = Ga(end-terminate:1:end,1:1:end-terminate-1)*(Ga(1:aP+aN,1:aP+aN)\Ya);
%     YUa = min(YUa, indicate(:));
%     YUa = Ga(end-terminate:1:end,1:1:end-terminate-1)*invGLLa*Ya;
%%%%%%%

%%%%%%%
% target classifier
    Wt = Pk(aP+aN+1:end,aP+aN+1:end);
%     Wt = Pkt;
    Dt = diag(ones(size(sum(Wt,2)))./sum(Wt,2));
    deltat = inv(Dt) - Wt;
    Mdeltat = beta*(deltat + eye(size(deltat,2))*(1/(sig^2)));
    Gt = inv(Mdeltat);
%     invGLLt = inv(Gt(1:tP+tN,1:tP+tN));
    YUt = Gt(end-terminate:1:end,1:1:end-terminate-1)*(Gt(1:tP+tN,1:tP+tN)\Yt); 
%     YUt = min(YUt, indicate(:));
%     YUt = Gt(end-terminate:1:end,1:1:end-terminate-1)*invGLLt*Yt;
%%%%%%%
    
    [proba,IDXa] = sort(YUa,'descend');
    [probt,IDXt] = sort(YUt,'descend');
    
 %%%%%%%
 % Fusion
    for j = 1:1:pool
        if(YUt(IDXa(j)) > probt(pool+1))
            numI = numI+1;
            Fua = [Fua IDXa(j)];
        end
        if(YUa(IDXt(j)) > proba(pool+1))
            Fut = [Fut IDXt(j)];
        end
    end
    
    if(numI > pool/2)
        Cas = 1;
        Fu = Fua;
    else
        Cas = 2;
        if(size(Fut,2) == 0)
            Fu = IDXa(1:pool/2);
        else
%             Fu = IDXa(1:pool/2);
            Fu = Fut;
        end
    end
 %%%%%%%
    flag = 1;
end

if (~isfield(param,'probidx'))  param.probidx = [];  end
if(size(Fu,2) > 5)
    param.est = affparam2mat(mean(param.param(:,Fu(1:5)),2));
else
    param.est = affparam2mat(mean(param.param(:,Fu(:)),2));
end
param.reser = param.est;
    
if (Cas == 0 || Cas ==1)
    opt.affsig = [Width/4,Height/4,.01,.00,.002,.000]; 
    opt.numsample = 300;
else
    opt.affsig = [Width/3.5,Height/3.5,.01,.00,.002,.000]; 
    opt.numsample = 450;
end
    
param.wimg = warpimg(frm, param.est, sz);

B = cat(1,0,affparam2geom(param.est(:)));

if (mod(f,6) == 0) %auxiliary samples collected at intervals of 6
    Wimgs.aPosi = [Wimgs.aPosi CovLognew(Interfrm,frm,affparam2geom(param.est(:)),dgridNum)];
    WimgO.aPosi = [WimgO.aPosi param.wimg(:)];
    paramN = [];
    paramN1 = cat(2,B(2:7)+[-B(4)*psize(1)/dgrid 0 0 0 0 0]',B(2:7)+[B(4)*psize(1)/dgrid 0 0 0 0 0]',B(2:7)+[0 -B(4)*psize(1)*B(6)/dgrid 0 0 0 0]',B(2:7)+[0 B(4)*psize(1)*B(6)/dgrid 0 0 0 0]');
    halfw_partical = paramN1(3,:)*sz(1)*0.5;
    halfh_partical = paramN1(5,:).*halfw_partical;
    x1_partical = paramN1(1,:) - halfw_partical;
    y1_partical = paramN1(2,:) - halfh_partical;
    x2_partical = paramN1(1,:) + halfw_partical;
    y2_partical = paramN1(2,:) + halfh_partical;
    for i = 1:1:size(paramN1,2)
        if (x1_partical(i) < 3 || x1_partical(i) > x2_edge || y1_partical(i) < 3 || y1_partical(i) > y2_edge || x2_partical(i) > (size(frm,2)-2) || x2_partical(i) < x1_edge || y2_partical(i) > (size(frm,1)-2) || y2_partical(i) < y1_edge)
            % Excluding the samples not in the view
        else
            paramN = [paramN paramN1(:,i)];
        end
    end
    wimgN = warpimg(frm, affparam2mat(paramN), sz);
    wimgN = reshape(wimgN,[N,size(paramN,2)]);
    Wimgs.aNega = [Wimgs.aNega CovLognew(Interfrm,frm,paramN,dgridNum)];
    WimgO.aNega = [WimgO.aNega wimgN];
    if (size(Wimgs.aPosi,2) > Num.aPosi)
        Idi = eye(Num.aPosi,Num.aPosi);
        Wimgs.aPosi = Wimgs.aPosi * cat(1,eye(1,Num.aPosi),zeros(size(Wimgs.aPosi,2)-Num.aPosi,Num.aPosi),Idi(2:end,:));
    end
    if (size(Wimgs.aNega,2) > Num.aNega)
        Idi = eye(Num.aNega,Num.aNega);
        Wimgs.aNega = Wimgs.aNega * cat(1,eye(4,Num.aNega),zeros(size(Wimgs.aNega,2)-Num.aNega,Num.aNega),Idi(5:end,:));
    end
    if (size(WimgO.aPosi,2) > Num.aPosi)
        Idi = eye(Num.aPosi,Num.aPosi);
        WimgO.aPosi = WimgO.aPosi * cat(1,eye(1,Num.aPosi),zeros(size(WimgO.aPosi,2)-Num.aPosi,Num.aPosi),Idi(2:end,:));
    end
    if (size(WimgO.aNega,2) > Num.aNega)
        Idi = eye(Num.aNega,Num.aNega);
        WimgO.aNega = WimgO.aNega * cat(1,eye(4,Num.aNega),zeros(size(WimgO.aNega,2)-Num.aNega,Num.aNega),Idi(5:end,:));
    end
end

Wimgs.tPosi = [Wimgs.tPosi CovLognew(Interfrm,frm,affparam2geom(param.est(:)),dgridNum)];
WimgO.tPosi = [WimgO.tPosi param.wimg(:)];

current_state = [B(2) B(3) B(4)*psize(1) B(4)*psize(1)*B(6)];
[targetN, paramN] = sampleImage(frm,current_state,psize,Num.tNega);
Wimgs.tNega = CovLognew(Interfrm,frm,paramN,dgridNum);
WimgO.tNega = targetN;
if (size(Wimgs.tPosi,2) > Num.tPosi && flag == 1)
    Wimgs.tPosi = Wimgs.tPosi * cat(1,zeros(size(Wimgs.tPosi,2)-Num.tPosi,Num.tPosi),eye(Num.tPosi,Num.tPosi));
end
if (size(WimgO.tPosi,2) > Num.tPosi && flag == 1)
    WimgO.tPosi = WimgO.tPosi * cat(1,zeros(size(WimgO.tPosi,2)-Num.tPosi,Num.tPosi),eye(Num.tPosi,Num.tPosi));
end

% figure(11);
% Imshow(cat(2,WimgO.tPosi,zeros(N,22),WimgO.tNega,zeros(N,24),WimgO.aPosi(:,1:end-delete),zeros(N,6),WimgO.aNega(:,1:end-delete*4)));
% 
% figure(13);
% plot(f,Cas,'*');
% hold on;






















