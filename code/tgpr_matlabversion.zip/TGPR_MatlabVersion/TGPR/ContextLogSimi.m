function [ P,Pk,Simila,Sknn,S ] = ContextLogSimi( gridnum,Interfrm,frm,Wimgs,X,ktest,pha,S )
%%
% TGPR: Transfer Learning Based Visual Tracking with Gaussian Process Regression
%
% Code to accompany the paper:
%   Transfer Learning Based Visual Tracking with Gaussian Process Regression
%   Jin Gao, Haibin Ling, Weiming Hu, Junliang Xing
%   ECCV2014, Part III, LNC 8691, pp. 188-203, 2014
%
% Copyright (C) 2014 Jin Gao
%
% This file is part of TGPR.
% costruKernel

[ud,un] = size(X);
[d,n] = size(Wimgs);
% pha = 3.9; %1.9
kNN = ktest;
% num = floor(sqrt(d/21));
num = gridnum(1);
Simila = zeros(un+n,un+n);
normalize = 0;
Ucoor = zeros(4,un);
w = X(3,:)*(16*num)/2;
h = w.*X(5,:);
Ucoor(1,:) = floor(X(1,:) - w);
Ucoor(2,:) = floor(X(2,:) - h);
Ucoor(3,:) = floor(X(1,:) + w);
Ucoor(4,:) = floor(X(2,:) + h);

uRM = zeros(21,un); % for each pixel, a 6-dimensinal feature vecter is extracted; and for each cell, a 6 by 6 matrix is extracted; and due to the symmetry of the matrix, a (6+6*6)/2 feature vecter is extracted for each cell
if (size(S,1) == 0)
    for i = 1:1:num
        for j = 1:1:num
            for k = 1:1:un
                uI = 255*frm(Ucoor(2,k):Ucoor(4,k),Ucoor(1,k):Ucoor(3,k));
%                 uI = 255*frm(max(1,Ucoor(2,k)):min(size(frm,1),Ucoor(4,k)),max(1,Ucoor(1,k)):min(size(frm,2),Ucoor(3,k)));
                usz=size(uI);
                uGridSize=floor(usz./num);%[7 7]
                Idx=(i-1)*uGridSize(1)+[1:uGridSize(1)];
                Idx = Idx + Ucoor(2,k)*ones(size(Idx));
                Idy=(j-1)*uGridSize(2)+[1:uGridSize(2)];
                Idy = Idy + Ucoor(1,k)*ones(size(Idy));
                uI2 = 255*frm(Idx,Idy);
                [M,N] = size(uI2);
                Coor_x=repmat([1:M]',1,N);
                Coor_y=repmat([1:N],M,1);
%                 uRM(:,k) = matrixlb(logm(eye(6)*1e-5+GPC(I(Idx,Idy),[1 1],[GridSize(1)-2 GridSize(2)-2])))];
                uRM(:,k) = matrixlb(logm(eye(6)*1e-5+Covariance(Coor_x,Coor_y,Interfrm.Intensity(Idx,Idy),Interfrm.Der_1x(Idx,Idy),Interfrm.Der_1y(Idx,Idy),Interfrm.GradMod(Idx,Idy),[1 1],[uGridSize(1) uGridSize(2)])));
                
            end
            RMD = cat(2,Wimgs(((i-1)*num+j)*21 - 20:((i-1)*num+j)*21,:),uRM);
            S = cat(3,S,ContextLogSimi0(RMD,ktest));
            Simila = Simila + S(:,:,(i-1)*num+j)*exp(-((i-num/2-0.5)^2 + (j-num/2-0.5)^2)/(2*pha^2));
            normalize = normalize + exp(-((i-num/2-0.5)^2 + (j-num/2-0.5)^2)/(2*pha^2));
        end
    end
else
    for i = 1:1:num
        for j = 1:1:num
            Simila = Simila + S(:,:,(i-1)*num+j)*exp(-((i-num/2-0.5)^2 + (j-num/2-0.5)^2)/(2*pha^2));
            normalize = normalize + exp(-((i-num/2-0.5)^2 + (j-num/2-0.5)^2)/(2*pha^2));
        end
    end
end
    

Simila = Simila/normalize;
[sorted,index]=sort(Simila,2,'descend');
dist2find = find((Simila - repmat(sorted(:,kNN+2),[1 size(Simila,2)])) > 0);
Sknn = zeros(size(Simila));
Sknn(dist2find) = 1;

Scontext = Simila;
% Scontext = Scontext./repmat(sum(Scontext,2),[1 size(Scontext,2)]);
P = Scontext;
Scontext = Scontext.*Sknn; 
Pk = Scontext;

end

