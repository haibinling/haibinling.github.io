function RMData =GetRMData(data,sz,RMData,mode_num)
if mode_num==5
    %%%%%%%%
    C=GPC(data,sz,[1 1],[sz(1)-2 sz(2)-2]);
    RMData{1}=[RMData{1} Matrix2Vector(logm(C+1e-35))];
    % %%%%%%%%
    C=GPC(data,sz,[1 1],[ sz(1)-2 floor(sz(2)/2)-1]);
    RMData{2}=[RMData{2} Matrix2Vector(logm(C+1e-35))];
    %%%%%%%%
    C=GPC(data,sz,[1 floor(sz(2)/2)-1],[ sz(1)-2 sz(2)-2]);
    RMData{3}=[RMData{3} Matrix2Vector(logm(C+1e-35))];
    %%%%%%%%
    C=GPC(data,sz,[1 1],[ floor(sz(1)/2)-1 sz(2)-2]);
    RMData{4}=[RMData{4} Matrix2Vector(logm(C+1e-35))];
    %%%%%%%%
    C=GPC(data,sz,[floor(sz(2)/2)-1 1],[sz(1)-2 sz(2)-2]);
    RMData{5}=[RMData{5} Matrix2Vector(logm(C+1e-35))];
else
    C=GPC(data,sz,[1 1],[sz(1)-2 sz(2)-2]);
    RMData=[RMData Matrix2Vector(logm(C+1e-35))];
end
end