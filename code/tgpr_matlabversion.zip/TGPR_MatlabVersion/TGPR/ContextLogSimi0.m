function [ S ] = ContextLogSimi0( X,ktest )
%%
% TGPR: Transfer Learning Based Visual Tracking with Gaussian Process Regression
%
% Code to accompany the paper:
%   Transfer Learning Based Visual Tracking with Gaussian Process Regression
%   Jin Gao, Haibin Ling, Weiming Hu, Junliang Xing
%   ECCV2014, Part III, LNC 8691, pp. 188-203, 2014
%
% Copyright (C) 2014 Jin Gao
%
% This file is part of TGPR.
% costruKernel
RMData = X;
[d,n] = size(X);

kNN = ktest;
X2=sum(RMData.^2,1);
dist2=repmat(X2,n,1)+repmat(X2',1,n)-2*RMData'*RMData;
[sorted,index]=sort(dist2,1);
kNNdist2=max(sorted(7,:),0);
dist2find = find((dist2 - repmat(sorted(kNN+2,:)',[1 size(dist2,2)])) < 0);
Sknn = zeros(size(dist2));
Sknn(dist2find) = 1;
localscale=sqrt(kNNdist2);
LocalScale=localscale'*localscale;
flag=(LocalScale>0);
% LocalScale(flag) = 2*(abs(sum(sum(sqrt(dist2)))/(n*n))).^2;
Scontext=zeros(n,n);
dist2tmp=dist2;
Scontext(flag)=exp(-dist2tmp(flag)./LocalScale(flag));
S = Scontext;


end

