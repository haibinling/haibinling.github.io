#include <time.h>
#include <stdio.h>
#include "emdL1.h"

void	GetRandHistogram(double *H, int n);

int main()
{
	int	n1,n2,n3,nB;
	double	*h1,*h2;
	double	d;

	EmdL1	em;			// EMD_L1 class

	// run experiments with EMDL1 for 2D histograms
	n1	= 8;
	n2	= 10;
	nB	= n1*n2;		// number of bins
	h1	= new double[nB];
	h2	= new double[nB];
	GetRandHistogram(h1,nB);
	GetRandHistogram(h2,nB);

	d	= em.EmdDist(h1,h2,n1,n2);			// 2D EMD_L1

	printf("For 2D histograms,  EmdL1(h1,h2)=%lf\n", d);
	delete	[]h1;
	delete	[]h2;
				
	// run experiments with EMDL1 for 3D histograms
	n1	= 4;
	n2	= 9;
	n3	= 3;
	nB	= n1*n2*n3;		// number of bins
	h1	= new double[nB];
	h2	= new double[nB];
	srand( (unsigned)time( NULL ) );
	GetRandHistogram(h1,nB);
	GetRandHistogram(h2,nB);

	d	= em.EmdDist(h1,h2,n1,n2,n3);		// 3D EMD_L1

	printf("For 3D histograms,  EmdL1(h1,h2)=%lf\n", d);
	delete	[]h1;
	delete	[]h2;

	return 0;
}


/********************************************************/
void GetRandHistogram(double *H, int n)
{
	int		r,k;
	double	dSum= 0;
	double	*p	= H;
	for(k=0; k<n; ++k)
	{
		r		= rand();
		dSum   += (double)r;
		*(p++)	= (double)r;
	}

	p	= H;
	for(k=0; k<n; ++k)
	{
		*(p++) /= (double)dSum;
	}
}

