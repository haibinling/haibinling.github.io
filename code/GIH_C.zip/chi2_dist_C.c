#include "mex.h"

/*-----------------------------------------------------------------------
% Chi-square distance
%		 d2 = chi2_dist(H1,H2)
%	This function compute the chi-square distance between distributions.
%	
% Input
%	H1	: m X n1, each column indicates a distribution histogram
%	H2	: m X n2, each column indicates a distribution histogram
% Output
%	ds	: n1 x n2, with d2(i,j) indicating the chi-square distance between 
%			H1(:,i) and H2(:,j), i.e.
% 			d2(i) = 0.5 * sum(((H1(:,i)-H2(:,j)).^2)./(H1(:,i)+H2(:,j)))



 ------------------------------------------------------------------------*/
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
	mxArray	*pMxD2;						/* input and output */
	double	*pH1, *pH2,   *pD2;

	double	*sc1,*sc2,*pCur;
	int		n1,n2,m1,m2;
	int		r,c,k;
	double	dis,tmp;


    /* Analyse input data */
    
	pH1		= mxGetPr(prhs[0]);
    m1		= mxGetM(prhs[0]);
    n1		= mxGetN(prhs[0]);
    
    pH2		= mxGetPr(prhs[1]);
    m2		= mxGetM(prhs[1]);
    n2		= mxGetN(prhs[1]);


    /* Create output matrices and initilize */
	if(m1!=m2){
		printf("Input matrix should have same number of rows!\n");
		pMxD2	= 0;
		return;
	}

    pMxD2	= mxCreateDoubleMatrix(n1,n2,mxREAL);
    pD2		= mxGetPr(pMxD2);


	/* compute the distance between the r-th point in shape 1
								and the c-th point in shape 2 */
	pCur	= pD2;
	for(c=0;c<n2;++c)
	{
		sc2	= pH2+c*m2;
		for(r=0;r<n1;++r)
		{
			sc1	= pH1+r*m1;
			dis	= 0;
			for(k=0;k<m1;++k)
			{
				tmp	= sc1[k]+sc2[k];
				if(tmp>0.000001)
					dis	+= (sc1[k]-sc2[k])*(sc1[k]-sc2[k])/tmp;
			}

			*pCur	= .5*dis;
			++pCur;
		}
	}


    /* Return */
    plhs[0] = pMxD2;
}
