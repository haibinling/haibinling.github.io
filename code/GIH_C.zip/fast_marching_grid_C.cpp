/*
% Fast Marching Level Set
% 			function T = fast_marching_grid(Z,s)
% Input: 
%	Z 		: surface matrix, where Z(y,x) is the height at point (x,y)
%	s		: s=(sx,sy) is the start point for the shortest path
%	fg_mask	: foreground mask
%	F		:
%	d_ceiling	: only find the geodesic distance within d_ceiling
%
% Output:
%	T		: distance matrix, where T(y,x) is the shortest path distance from 
%				the start point s=(sx,sy) to (x,y)
%
% Remark	: Find shortest pathes on a 3D surface, the surface is represented by a matrix
%				Z, where (x,y,Z(y,x)) is the 3D point on the surface.
%				s=(sx,sy) is the start point on the surface.
%
% Complexity: O(n*log(n)), n is the number of nodes
%
% REF		: Sethian 1996, A fast marching level set method for monotonically
%				advancing fronts
%
% Author	:	Haibin Ling, hbling AT umiacs.umd.edu
%				Computer Science Department, University of Maryland, College Park
%

	function T = fast_marching_grid_C(Z,s,fg_mask,F,d_ceiling)

*/

/* common functions */
#include "common_matlab.h"

bool fast_march_grid (	double* T,
						double* Z, int nRow, int nCol,
						int sx, int sy,
						double* fg_mask,
						double*	F,
						double	d_ceiling);

bool	bDebug	= 1;


/*----------------------------------------------------------------------*/
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
	mxArray *pMxT;
	double  *pZ,  *pS,  *pFgMask,  *pF,  *pT;
	double	d_ceiling;
	int		nRow, nCol, sx, sy;
	bool	bRes=false;

    /* Prepare for the data */
	pZ		= mxGetPr(prhs[0]);
	nRow	= mxGetM(prhs[0]);
	nCol	= mxGetN(prhs[0]);

	pS		= mxGetPr(prhs[1]);		// start point
	pFgMask	= mxGetPr(prhs[2]);		// mask
	pF		= mxGetPr(prhs[3]);		// velocity field

	d_ceiling	= -1;
	if(nrhs>4)	d_ceiling	= *mxGetPr(prhs[4]);



    /* Create output matrices and initilize */
    pMxT	= mxCreateDoubleMatrix(nRow,nCol,mxREAL);
    pT		= mxGetPr(pMxT);


	sx		= ROUND(pS[0])-1;		// -1 because index start from 0 in C
	sy		= ROUND(pS[1])-1;
	if(sx<1 || sx>=nCol-1 || sy<1 || sy>=nRow-1)
		printf("\n The start point can not be the boundary of the image!\n");
	else
		bRes	= fast_march_grid (	pT,
									pZ, nRow, nCol,
									sx, sy,
									pFgMask,
									pF,
									d_ceiling);
	if(!bRes) {
		printf("\n Fast_match_grid failed!\n");
		printf("\tsx=%d,sy=%d,nRow=%d,nCol=%d\n", sx,sy,nRow,nCol);
	}


    /* Return */
    plhs[0] = pMxT;
}



/*----------------------------------------------------------------------*/

bool fast_march_grid (	double* T,
						double* Z, int nRow, int nCol,
						int sx, int sy,
						double* fg_mask,
						double*	F,
						double	d_ceiling)
{
	int		*flags=0,flg;
	int		*bandX,*bandY,n_band;
	double	*bandT;
	int		x_min,y_min,id_min;
	int		Xnb[4],Ynb[4],x,y,idnb,inb;
	double	VERYFAR, T_min,T_tmp,Tx_min,Tx_max,Ty_min,Ty_max,Ts[4];
	double	f,f_rt, a,b,c,delta;
	int		nAll,i,j,n_len,iPos,iCur;

	/* -----------------------------------------------------------
		initialization 
	*/
	nAll	= nRow*nCol;
	VERYFAR	= nAll*1000;

	flags	= new int[nAll];
	bandX	= new int[(int)(.5*nAll)];
	bandY	= new int[(int)(.5*nAll)];
	bandT	= new double[(int)(.5*nAll)];

	/* T, the distances */
	for(i=0;i<nAll;i++)	
		T[i]	= VERYFAR;

	/* flags,	-1 : FAR AWAY    0 : in the Narrow Band;
				 1 : Finished		-2 : additional boundary and background	*/
	for(i=0;i<nRow;i++)
		flags[i]	= -2;
	for(i=nRow;i<nAll-nRow;i++)
		flags[i]	= fg_mask[i]>.5 ? -1 : -2;
	for(i=nAll-nRow;i<nAll;i++)
		flags[i]	= -2;

	for(i=nRow;i<=nAll-nRow;i+=nRow)	{
		flags[i]	= -2;
		flags[i-1]	= -2;
	}

	/* start point */
	T[sx*nRow+sy]		= 0;	
	flags[sx*nRow+sy]	= 0;

	n_band		= 1;
	bandT[0]	= 0;	
	bandX[0]	= sx;
	bandY[0]	= sy;

	/* -----------------------------------------------------------
		Iteration: Marching Forward 
	*/
	if(d_ceiling<0)	d_ceiling = VERYFAR+2;
	while(n_band>0)
	{
		//if(bDebug)	printf("\nn_band=%4d \t",n_band);

		//- Find the minimum T value in the band, store as [x_min,y_min]
		x_min		= bandX[0];
		y_min		= bandY[0];
		id_min		= XY2ID(x_min,y_min,nRow);
		//printf("x_min=%d,y_min=%d,T[min]=%lf\n",x_min,y_min,T[id_min]);

		//printf("T=%lf,d_ceiling=%lf\n",T[id_min],d_ceiling);
		if(T[id_min]>d_ceiling)	break;		// stop when the maximum distance is reached


		//- Remove [x_min,y_min] from the band
		flags[id_min]	= 1;	// set it as Finished
		n_band--;
		for(j=0;j<n_band;j++)	{
			bandT[j]	= bandT[j+1];
			bandX[j]	= bandX[j+1];
			bandY[j]	= bandY[j+1];
		}
		
		//- Update band and neighbor T values
		Xnb[0]	= x_min-1;		Ynb[0]	= y_min;
		Xnb[1]	= x_min;		Ynb[1]	= y_min+1;
		Xnb[2]	= x_min+1;		Ynb[2]	= y_min;
		Xnb[3]	= x_min;		Ynb[3]	= y_min-1;
		for(inb=0;inb<4;++inb)
		{
			x	= Xnb[inb];
			y	= Ynb[inb];
			WRONG3(!(0<=x&&x<nCol),"wrong x\t",false);
			WRONG3(!(0<=y&&y<nRow),"wrong y\t",false);
			idnb= XY2ID(x,y,nRow);
			flg	= flags[idnb];
			/*printf("\n  x=%d,y=%d, inb=%d, flg=%d\t",x,y,inb,flg);*/


			if(flg==-1)	// add into Band
			{			
				flg	= 0;
				flags[idnb]	= flg;
				bandX[n_band]	= x;
				bandY[n_band]	= y;
				n_band++;
			}

			if(flg==0)
			{				
				/*/ Update the T value at [x,y], choose the minimum for all solutions */
				Ts[0]	= MAT_GET(T,x-1,y,nRow);
				Ts[0]	= T[(x-1)*nRow+y];
				Ts[1]	= MAT_GET(T,x+1,y,nRow);
				Ts[2]	= MAT_GET(T,x,y-1,nRow);
				Ts[3]	= MAT_GET(T,x,y+1,nRow);
				
				f		= MAT_GET(F,x,y,nRow);
				f_rt	= sqrt(f);		//F_rt(y,x);

				T_min	= T[idnb];		// T_min stores the solution of the quadratic eq.
				Tx_min	= MIN(Ts[0],Ts[1]);
				Tx_max	= MAX(Ts[0],Ts[1]);
				Ty_min	= MIN(Ts[2],Ts[3]);
				Ty_max	= MAX(Ts[2],Ts[3]);

				/* investigate all possible solutions */
				/*- CASE 1: only one direction works */
				
				// greater than only one of the four neighbors
				T_tmp = MIN(Tx_min,Ty_min)+f_rt;
				if (T_tmp<T_min && T_tmp<=MAX(Tx_min,Ty_min) && T_tmp<=Tx_max && T_tmp<=Ty_max)
					T_min = T_tmp;
				
				// greater than two neighbors in the same direction
				// x direction
				T_tmp	= Tx_min+f_rt;
				if (T_tmp<T_min && T_tmp>=Tx_max && T_tmp<=Ty_min)
					T_min = T_tmp;
				
				// y direction
				T_tmp	= Ty_min+f_rt;
				if (T_tmp<T_min && T_tmp<=Tx_min && T_tmp>=Ty_max)
					T_min = T_tmp;

				
				/*- CASE 2, two directions, greater than two, three or four of the neighbors */
				a		= 1;
				b		= -(Tx_min+Ty_min);
				c		= .5*(Tx_min*Tx_min+Ty_min*Ty_min-f);		// can be accerelate here
				delta	= b*b-4*a*c;
				if(delta>.0001)
				{
					T_tmp	= (-b+sqrt(delta))/2/a;
					if(T_tmp<T_min && T_tmp>Tx_min && T_tmp>Ty_min)
						T_min = T_tmp;
				}
			

				/* Update T and sort the band */
				/*
				if(bDebug && T_min>500)	{
					printf("\nT_min=%7.2lf  \t",T_min);
					for(j=0;j<4;j++)	printf("Ts[%d]=%6.0f\t",j,Ts[j]);
					printf("\nx=%d,y=%d",x,y);
					WRONG(1);
					return false;
				}/**/

				
				iCur	= n_band-1;
				while(iCur>=0 && (bandX[iCur]!=x || bandY[iCur]!=y))		iCur--;
				WRONG2(iCur<0,"iCur<0\t");

				iPos	= iCur-1;
				while(iPos>=0 && bandT[iPos]>T_min)	
					iPos--;
				iPos++;
				for(j=iCur;j>iPos;j--)	{
					bandT[j]	= bandT[j-1];
					bandX[j]	= bandX[j-1];
					bandY[j]	= bandY[j-1];
				}

				bandX[iPos]	= x;
				bandY[iPos]	= y;
				bandT[iPos]	= T_min;
				T[idnb]		= T_min;
			}
		}// updating neighbors, end of inb
	} // iteration


	/* boundary and background processing */
	for(i=0;i<nAll;i++)
	{
		if(1!=flags[i])		// Finished
			T[i] = T_min*1.5;
	}

	delete []flags;
	delete []bandT;
	delete []bandX;
	delete []bandY;

	return true;
}
