/* This is a C verion of following matlab code, Haibin Ling, 09/04/2004
    
[Hc,H]	= hist_count_C (iIs,iGs,n_colorbin,n_geobin);
H and Hc is n_colorbin X n_geobin histogram, where Hc is the count, H is normalized

	H_count	= zeros(n_colorbin,n_geobin);	% intensity-geodesic 2D histogram
	for ic=1:n_colorbin
		for ig=1:n_geobin
			Hc(ic,ig)	= Hc(ic,ig)+length(find(iIs==ic & iGs==ig));
		end
	end

	%- normalize
	H			= Hc;
	sumH		= sum(H,1);
	idx_0		= find(sumH<.5);
	H(:,idx_0)	= 1;
	sumH(idx_0)	= n_colorbin;
	H			= H./(repmat(sumH,n_colorbin,1));		% normalize each colomn
	H			= H/sum(H(:));							% normalize the whole histogram

*/

#include "common_matlab.h"

void hist_count(double* Hc, double* H, double *Is, double* Gs, int n_samp, 
		   int n_colorbin, int n_geobin);

/*****************************************************************************

	[Hc,H]	= hist_count_C (iIs,iGs,n_colorbin,n_geobin);

 *****************************************************************************/
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
    /* Input data */
	double	*Is		= mxGetPr(prhs[0]);
	double	*Gs		= mxGetPr(prhs[1]);
    int		n_samp	= mxGetM(prhs[0]);

   	int		n_colorbin	= ROUND(*mxGetPr(prhs[2]));
   	int		n_geobin	= ROUND(*mxGetPr(prhs[3]));

	//printf("n_colorbin=%d,n_geobin=%d,n_samp=%d\n",n_colorbin,n_geobin,n_samp);


    /* Output data */
    mxArray	*pMxHc	= mxCreateDoubleMatrix(n_colorbin,n_geobin,mxREAL);
    double	*Hc		= mxGetPr(pMxHc);
    mxArray	*pMxH	= mxCreateDoubleMatrix(n_colorbin,n_geobin,mxREAL);
    double	*H		= mxGetPr(pMxH);

	/* call algorithm */
	hist_count(Hc, H, Is, Gs, n_samp, n_colorbin, n_geobin);

    /* Return */
    plhs[0] = pMxHc;
    plhs[1] = pMxH;
}


/*****************************************************************************/
void hist_count(double* Hc, double* H, double *Is, double* Gs, int n_samp, 
		   int n_colorbin, int n_geobin)
{
	int ic,ig,i;
	double dTmp	= 1/n_colorbin/n_geobin;
	double dSum0,dSumAll=0;

	// Initilize
	for(i=0; i<n_colorbin*n_geobin; ++i)
	{
		Hc[i]	= 0;
		H[i]	= dTmp;
	}

	// Count
	for(i=0; i<n_samp; ++i)
	{
		ic		= ROUND(Is[i])-1;
		ig		= ROUND(Gs[i])-1;
		if(0<=ic && ic<n_colorbin && 0<=ig && ig<n_geobin)
			MAT_SET(Hc,ig,ic, MAT_GET(Hc,ig,ic,n_colorbin)+1, n_colorbin);
	}

	// Normalize
	for(ig=0; ig<n_geobin; ++ig)
	{	
		dSum0	= 0;
		
		for(ic=0; ic<n_colorbin; ++ic)
		{
			dSum0	+= MAT_GET(Hc,ig,ic,n_colorbin);
		}

		if(dSum0>0)
		{
			dSum0	*= n_geobin;
			for(ic=0; ic<n_colorbin; ++ic)
			{
				MAT_SET(H,ig,ic,MAT_GET(Hc,ig,ic,n_colorbin)/dSum0,n_colorbin);
			}
		}
	}

	return;
}
