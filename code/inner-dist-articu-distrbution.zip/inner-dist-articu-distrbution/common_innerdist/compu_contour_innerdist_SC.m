% The algorithm:
%	
%	1. Initialize the graph
%		for each p1
%			for each p2
%				if (p1,p2) inside the shape
%					add edge e(p1,p2) into E
%					set dis_mat(p1,p2)=dis_mat(p2,p1)
%					set ang_mat(p1,p2), ang_mat(p2,p1)
%					set viewable(p1,p2)=viewable(p2,p1)=1
%
%	2. for each p1, 
%		2.1 compute the distance and angle from it to all other points
%			initialize edge list E1
%			"bellman_ford"
%		2.2 compute shape context at p1
%
%	Haibin Ling, hbling AT umiacs.umd.edu
%	Computer Science Dept. University of Maryland, College Park
%

function [sc,V,E,dis_mat,ang_mat] = compu_contour_innerdist_SC( ...
											cont, fg_mask, ...
											n_dist, n_theta, ...
											bTangent, bSmoothCont, ifig)

if ~exist('bSmoothCont')	bSmoothCont = 0;	end
if ~exist('bTangent')		bTangent = 0;		end

%------ Parameters ----------------------------------------------
n_pt= size(cont,1);
X	= cont(:,1);
Y	= cont(:,2);
V	= cont;


% keyboard
E	= build_graph_contour_C(X,Y,fg_mask,bSmoothCont);
E	= E';

% disp_graph(V,E);		keyboard;

%-- Orientations and geodesic distances between all landmark points ---------
[dis_mat,ang_mat] = bellman_ford_ex_C(X,Y,E);


%-- Normalize shape context with the tangent orientation --------------------
if bTangent
	Xs	= [X(end); X; X(1)];
	Ys	= [Y(end); Y; Y(1)];
	gX	= gradient(Xs);
	gY	= gradient(Ys);

	thetas	= atan2(gY,gX);
	thetas	= thetas(2:end-1);
	thetas	= repmat(thetas',n_pt,1);
	
	ang_mat	= ang_mat-thetas;
	
	idx		= find(ang_mat>pi);
	ang_mat(idx)	= ang_mat(idx)-2*pi;
	idx		= find(ang_mat<-pi);
	ang_mat(idx)	= ang_mat(idx)+2*pi;
end



%-- Compute shape context  ----------------------------------------
n_pt		= size(V,1);
dists		= zeros(n_pt-1,n_pt);		% distance and orientation matrix, the i-th COLUMN contains
angles		= zeros(n_pt-1,n_pt);		% dist and angles from i-th point to all other points
id_gd		= setdiff(1:n_pt*n_pt, 1:(n_pt+1):n_pt*n_pt);
dists(:)	= dis_mat(id_gd);
angles(:)	= ang_mat(id_gd);

% tic;
[sc]		= comp_sc_hist(dists,angles,n_dist,n_theta);
% disp(['computing shape context take ' i2s(toc) ' seconds']);

% ifig	= 1;
if exist('ifig') & ifig>0
	figure(ifig);	clf; hold on;	imagesc(fg_mask);colormap(gray);	axis equal;	
	sGraph	= ['|V|=' i2s(size(V,1)) ', |E|=' i2s(size(E,1))];
	%disp_graph(V,E);		title(sGraph);
	
	figure(ifig+4);
	disp_schist(fg_mask,V,sc,n_dist,n_theta);
	
	keyboard;
end

return;



%-------------------------------------------------------------------------------
% function [V,E,dis_mat,ang_mat,viewable] = build_graph_contour(im,X,Y)
% 	Initialize the graph from contour points
%		for each p1
%			for each p2
%				if (p1,p2) inside the shape
%					add edge e(p1,p2) into E
%					set dis_mat(p1,p2)=dis_mat(p2,p1)
%					set ang_mat(p1,p2), ang_mat(p2,p1)
%					set viewable(p1,p2)=viewable(p2,p1)=1


% function [V,E,dis_mat,ang_mat,viewable] = build_graph_contour(fg_mask,X,Y)
% 	
% 	[nRow,nCol]	= size(fg_mask);
% 	V			= [X,Y];%(idx_fg),Y(idx_fg),im_node(idx_fg)];
% 	n_V			= length(X);
% 	E			= ones(3,n_V*n_V);		% locate memory for edge list
% 	n_E			= 0;
% 	dis_mat		= inf*ones(n_V,n_V);	% each COLUMN is a record at a point
% 	ang_mat		= inf*ones(n_V,n_V);
% 	viewable	= zeros(n_V,n_V);
% 	
% 	for p1=1:n_V
% % 		p1
% 		dis_mat(p1,p1)	= 0;
% 		viewable(p1,p1)	= 1;
% 		x1	= X(p1);
% 		y1	= Y(p1);
% 		for p2=p1+1:n_V
% 			x2	= X(p2);
% 			y2	= Y(p2);
% 
% 			% test if (p1,p2) inside the shape
% 			bIn	= 0;
% 			n	= max(floor(abs(x2-x1)),floor(abs(y2-y1)))+1;
% 			if n<=2
% 				bIn	= 1;
% 			else
% 				xs	= round(linspace(x1,x2,n));
% 				ys	= round(linspace(y1,y2,n));
% 				ids	= (xs(2:end-1)-1)*nRow + ys(2:end-1);
% 				if sum(fg_mask(ids))==n-2
% 					bIn	= 1;
% 				end
% 			end
% 			
% 			% if inside, set dis_mat, ang_mat, viewable
% 			if bIn
% 				% set dis_mat, ang_mat, viewable
% 				dx				= x2-x1;
% 				dy				= y2-y1;
% 				dis				= sqrt(dx*dx+dy*dy);
% 				dis_mat(p1,p2)	= dis;
% 				dis_mat(p2,p1)	= dis;
% 				ang_mat(p1,p2)	= atan2(dy,dx);
% 				ang_mat(p2,p1)	= atan2(-dy,-dx);
% 				viewable(p1,p2)	= 1;
% 				viewable(p2,p1)	= 1;
% 				
% 				% add edge
% 				n_E				= n_E+1;
% 				E(:,n_E)		= [p1,p2,dis]';
% % 				n_E				= n_E+1;
% % 				E(:,n_E)		= [p2,p1,dis]';
% 			end				
% 		end
% 	end
% 
% 	% truncate if necessary
% 	if n_E<size(E,2)	E=E(:,1:n_E);	end		
% 	
% 	% display
% 	if 0
% 		figure; imagesc(fg_mask);colormap(gray);	axis equal;	disp_graph(V,E');
% 		keyboard;
% 	end
% return;