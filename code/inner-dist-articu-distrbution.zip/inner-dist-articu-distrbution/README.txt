This package contains the code for the inner-distance shape context (IDSC) in comparison with the shape context (SC). The experiments test these two techniques on the articulated shape data set (also contains in the package).

The IDSC and SC codes are mainly in 'common_innerdist/' and the data and results are saved in 'data'.

Three steps to run the code:

1. Download the package and unzip it - keep the directory structure.
2. Run 		
	Articu_innerSC 
   for IDSC.
3. Run 
	Articu_normalSC
   for SC.

NOTE: The algorithm deals with binary images only, where 1 means the foreground object and 0 means the background. The contour is extracted from the image and the image is also used for foreground mask.

Please refer to
	H. Ling and D.W. Jacobs. Shape Classification Using the Inner-Distance, IEEE Trans on Pattern Anal. and Mach. Intell. (PAMI), 29(2):286-299, 2007. 
for details and forward any comments to  hbling AT umiacs.umd.edu

Haibin Ling
Computer and Information Science Department, Temple University.

Update 7/1/2011: a robust is_clockwise.m is included to fix a bug. 