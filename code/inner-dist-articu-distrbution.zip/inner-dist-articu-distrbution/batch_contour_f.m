function [articu_cont,articu_cont_n] = batch_contour_f(sdir,n_contsamp)

fprintf('Compute articu contours ......................... \n');
		
sOriCont		= [sdir 'articu_cont.mat'];

n_class		= 8;
n_obj		= 5;

% original contour
if ~exist('n_contsamp')
	articu_cont		= cell(n_class,n_obj);
	figure(20); clf; hold on;
	for iC=1:n_class
		for iO=1:n_obj
			fn	= [sdir i2s(iC,2) '_' i2s(iO,2) '_m.bmp'];
			im	= double(imread(fn));
	
			%- Extract contour, count only the longest contours
			[Cs]	= boundary_extract_binary(im);
			n_max	= 0;
			i_max	= 0;
			for ii=1:length(Cs)
				if size(Cs{ii},2)>n_max
					n_max = size(Cs{ii},2);
					i_max = ii;
				end
			end
			cont	= Cs{i_max}';

			% remove redundant point in contours
			cont		= [cont; cont(1,:)];
			dif_cont	= abs(diff(cont,1,1));
			id_gd		= find(sum(dif_cont,2)>0.001);
			cont		= cont(id_gd,:);
			
			% force the contour to be anti-clockwisecomputed above is at the different orientation
			bClock		= is_clockwise(cont,im);
			if bClock	cont	= flipud(cont);		end
			
			% start from bottom left
			[min_v,id]	= min(cont(:,2)+cont(:,1));
			cont		= circshift(cont,[length(cont)-id+1]);
			
			articu_cont{iC,iO}	= cont;
			%fprintf('%2d, original clockwise=%d\n', iO,bClock);
			if 1	% test
				subplot(5,8,iO*8-8+iC);	hold on;
				plot(cont(:,1),cont(:,2),'-');	
				plot(cont(1,1),cont(1,2),'r+');
				plot(cont(50,1),cont(50,2),'ro');
				title([i2s(length(cont))]);
				axis tight;	axis equal;	axis off;
% 				drawnow, keyboard;				
			end
		end
		print(20,'-r350', '-djpeg', [sdir 'cont.jpg']);
	end
	
	save(sOriCont,'articu_cont');
end



%-------------- downsampling contour
if exist('n_contsamp')
	sCont	= [sdir 'articu_cont_' i2s(n_contsamp) '.mat'];
	if ~exist('articu_cont')	load(sOriCont);	end

	figure(21); clf; hold on;
	for iC=1:n_class
		fprintf('Class %2d \n', iC);
		for iO=1:n_obj

			cont		= articu_cont{iC,iO};
			[XIs,YIs]	= uniform_interp(cont(:,1),cont(:,2),n_contsamp-1);
			cont		= [cont(1,:); [XIs YIs]];
			articu_cont{iC,iO}	= cont;
	
			if 1	%test
				subplot(5,8,iO*8-8+iC);	hold on;
				plot(cont(:,1),cont(:,2),'b-');
				plot(cont(1,1),cont(1,2),'r+');
				plot(cont(10,1),cont(10,2),'ro');
				%title([i2s(length(cont))]);
				axis tight;	axis equal;	axis off;
			end
		end
	end
	
	print(21,'-r300', '-djpeg',[sdir 'cont_' i2s(n_contsamp) '.jpg']);
	save(sCont,'articu_cont');
end

fprintf('\n    finished computing contours.\n');
