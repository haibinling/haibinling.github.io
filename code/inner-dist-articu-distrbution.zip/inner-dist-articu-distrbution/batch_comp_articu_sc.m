function articu_sc = batch_comp_articu_sc( sdir,sCont, n_dist,n_theta, bTangent, bSmoothCont, b_simplecont)

	if ~exist('b_simplecont')	b_simplecont=1;	end
	fprintf('Compute all shape context ...............................\n\n');

	load(sCont);		% get 'mpeg7_cont'
	articu_sc	= cell(8,5);
	
	for iC=1:8
		for iO=1:5
			fn	= [sdir i2s(iC,2) '_' i2s(iO,2) '_m.bmp'];
			im	= double(imread(fn));
			fprintf('%2d,%2d ', iC,iO);
			fg_mask		= double(im>.5);
		
			ifig		= -1;
			tic;
			if b_simplecont
				cont		= articu_cont{iC,iO};
				[sc,V,E,dis_mat,ang_mat] = compu_contour_innerdist_SC( ...
												cont, fg_mask, ...
												n_dist, n_theta, bTangent, bSmoothCont,...
												ifig);
			else
				conts		= articu_cont{iC,iO};
				[sc,V,E,dis_mat,ang_mat] = compu_multi_contour_innerdist_SC( ...
												conts, fg_mask, ...
												n_dist, n_theta, bTangent, bSmoothCont,...
												ifig);
			end
			n_time		= toc;	
			fprintf('|V|=%4d,   time=%5.2f\n', size(V,1), n_time);

			articu_sc{iC,iO}	= sc;

	% 		ssave		= [strtok(fn,'.') '_contsc.mat'];
	% 		save(ssave, 'sc','V','E','dis_mat','ang_mat');
			if 0
				figure(432); clf; hold on;
				plot(V(:,1),V(:,2),'k-');
				disp_graph(V,E);
				keyboard;
				disp_schist(fg_mask,V,sc,n_dist,n_theta);			
			end
		end
	end
