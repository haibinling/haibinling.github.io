function [articu_sc] = batch_comp_normal_sc(sdir,sCont,n_dist, n_theta, bTangent)

	fprintf('Compute all shape context ...............................\n\n');

	n_class	= 8;
	n_obj	= 5;
	articu_sc	= cell(n_class,n_obj);
	load(sCont);		% get 'articu_cont'

	fg_mask	= [];
	for iC=1:n_class
		for iO=1:n_obj
			tic;
			fprintf('class %2d, object %2d :  ', iC,iO);
			% fn	= [sdir i2s(iC,2) '_' i2s(iID,2) '.bmp'];
			% im0	= double(imread(fn));

			cont		= articu_cont{iC,iO};
			[sc,dis_mat,ang_mat] = compu_contour_SC( cont, n_dist, n_theta, bTangent);
			articu_sc{iC,iO}	= sc;
			
% 			keyboard;
			if 0 % demo
				figure(531);	clf; hold on;	
				disp_schist([],cont,sc,n_dist,n_theta);
			end
			
			n_time	= toc;	
			fprintf('|cont|=%4d,   time=%5.2f\n', size(cont,1), n_time);
		end
	end
