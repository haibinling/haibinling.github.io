function [dis_sc,match_cost,n_match] = dist_bw_sc_articu( sc1,sc2, V1,V2, search_step, num_start, ifig)

if ~exist('ifig') 		ifig=-1;	end


%-- compute SC distance b/w sc1 and sc2 and cost matrix
% if isempty(dis_sc)		dis_sc	= dist_bw_sc_C( sc1, sc2, 0);	end
[dis_sc,costmat]	= dist_bw_sc_C( sc1, sc2, 0);

match_cost	= 0;
n_match		= 1;


%- MATCHING
if 1
	if 1
		%thre				= mean(mean(costmat));
		thre				= .6;
		[cvec,match_cost]	= DPMatching_C(costmat,thre,num_start,search_step);
	else
		[cvec,match_cost]	= hungarian(costmat);		
	end
end

%-- point correspondences for computation of 
% n_pt		= size(sc1,2);
% id_gd1		= find(cvec<=n_pt);
% id_gd2		= cvec(id_gd1);
% pt_from		= V1(id_gd1,:);
% pt_to		= V2(id_gd2,:);
% n_match		= length(pt_from);

%-- display correspondence
% ifig	= 12;
if exist('ifig') & ifig>0
	figure(ifig); clf;	hold on;
	plot(V1(:,1),V1(:,2),'r.-');
	plot(V2(:,1)+150,V2(:,2),'b.-');
	plot([pt_from(:,1) pt_to(:,1)+150]', [pt_from(:,2) pt_to(:,2)]', '+-');
	axis equal;
	title(['#match=' i2s(n_match) ' cost=' num2str(match_cost)]);
	xlabel(['sc=' num2str(dis_sc) ' match_cost=' num2str(match_cost)]);
	keyboard
end

return;

