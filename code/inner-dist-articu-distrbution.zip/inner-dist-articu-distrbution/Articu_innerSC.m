% This experiment testing the effect of inner-distance shape context
% on the articulated shape database containing 25 objects. The result and the original shape 
% data are located at directory 'data/'
% 
% For details, please refer to
% 	H. Ling and D.W. Jacobs. Shape Classification Using the Inner-Distance, IEEE Trans on Pattern Anal. and Mach. Intell. (PAMI), 29(2):286-299, 2007. 
%
% Haibin Ling (hbling AT umiacs.umd.edu)
%	Computer Science Department, University of Maryland, College park

clear;
addpath common_innerdist;

ifig		= -1;
sdir		='data/';

%------ Parameters ----------------------------------------------
n_class		= 8;
n_obj		= 5;
n_objall	= n_obj*n_class;
n_bull		= 2*n_obj;
class_ids	= ceil((1:n_objall)/n_obj);
obj_ids		= repmat((1:n_obj)',n_class,1);

num_start	= 1;
search_step	= 1;
w			= [0,1];

%-- shape context parameters
n_dist		= 5;
n_theta		= 12;
bTangent	= 1;
bSmoothCont	= 1;
n_contsamp	= 200;
b_simplecont= 1;

%-- FILEs --------------------------------------------
sDisAngSamp	= ['_' i2s(n_dist,2) 'x' i2s(n_theta,2) 'x' i2s(n_contsamp,3)];
sCont		= [sdir 'articu_cont_' i2s(n_contsamp) '.mat'];
s_articu_sc	= [sdir 'IDSC' sDisAngSamp '.mat'];

fprintf('%s,\n\n', sDisAngSamp);


%-- Extract contours -------------------------------------------------------------
if 0
	[articu_cont] = batch_contour_f(sdir);
	[articu_cont] = batch_contour_f(sdir,n_contsamp);
end

%-- Compute or Load all the shape context data ------------------------------------
if 1
	[articu_sc] = batch_comp_articu_sc(sdir,sCont,n_dist, n_theta, bTangent, bSmoothCont,b_simplecont);
	save(s_articu_sc, 'articu_sc');
end


%-- classifying each object by comparing its SC to training objects -----------------
fprintf('Classifying each object by comparing its SC to training objects .............\n');
if ~exist('articu_cont')			load(sCont);			end
if ~exist('articu_sc')				load(s_articu_sc);		end

articu_sc		= articu_sc';

% following matrix store the distances
all_dists		= zeros(n_objall,n_objall);
sc_dists		= zeros(n_objall,n_objall);
mt_dists		= zeros(n_objall,n_objall);
num_matchs		= zeros(n_objall,n_objall);

% begin loop for all pair of images
n_goodall		= 0;
for o1=1:n_objall
	iC1		= class_ids(o1);
	iO1		= obj_ids(o1);
	% if iC1~=1 | iO1~=20	continue; end
	
	if(iO1==1) 		fprintf('\n');	end
	fprintf('Class %2d, Obj %2d --> ', iC1,iO1);
	tic;
	
	V1		= articu_cont{iC1,iO1};
	sc1		= articu_sc{o1};
% 	if 0
% 		figure(432); clf; hold on;
% 		disp_schist([],V1,sc1,n_dist,n_theta,6);
% 		continue;
% 	end

	%-- loop for object 2
	for o2=o1+1:n_objall
		iC2		= class_ids(o2);
		iO2		= obj_ids(o2);
		%if iC2==1	continue;	end

		sc2		= articu_sc{o2};
		V2		= articu_cont{iC2,iO2};

		[dis_sc,match_cost,n_match] = dist_bw_sc_articu( sc1,sc2, V1,V2, search_step, num_start, ifig);
		dis		= w(1)*dis_sc+w(2)*match_cost;

		sc_dists(o1,o2)		= dis_sc;
		sc_dists(o2,o1)		= dis_sc;
		mt_dists(o1,o2)		= match_cost;
		mt_dists(o2,o1)		= match_cost;
		num_matchs(o1,o2)	= n_match;
		num_matchs(o2,o1)	= n_match;
		all_dists(o1,o2)	= dis;
		all_dists(o2,o1)	= dis;
	end
	[tmpDist,tmpID]	= sort(all_dists(:,o1));
	top_class		= class_ids(tmpID(1:n_bull));
	n_good			= length(find(top_class==iC1));
	n_goodall		= n_goodall + n_good;
	score			= n_goodall/o1/n_obj;

	t=round(toc);
	fprintf('hit=%2d, score=%6.4f, %2ds   \n', n_good, score, t);
end

fprintf('\n\n%d class, %d obj, n_contsamp=%d, n_dist=%d, n_theta=%d \n', ...
		n_class,n_obj,n_contsamp,n_dist,n_theta);
fprintf('w=[%f,%f]\n',w(1),w(2));
fprintf('search_step=%d, num_start=%d\n', search_step, num_start);
fprintf('bTangent=%d, bSmoothCont=%d\n', bTangent,bSmoothCont);


[n_hits,topCs,topOs] = analyze_res(all_dists);
fprintf('Number of top 9 hits: ');
fprintf(' %2d', n_hits(2:10));

return;