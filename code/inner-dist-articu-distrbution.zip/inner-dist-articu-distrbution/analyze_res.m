function [n_hits,topCs,topOs] = analyze_res(dists)

if 1
	figure(543); clf; hold on; 
	imagesc(dists); 	axis equal; axis tight; colorbar; colormap(gray);
end

n_class		= 8;
n_obj		= 5;
n_objall	= n_class*n_obj;
class_ids	= ceil((1:n_objall)/n_obj);
obj_ids		= repmat((1:n_obj)',n_class,1);

[dis_sort, ids_sort] = sort(dists);
errs	= zeros(n_objall,n_obj);
%topCs	= zeros(n_objall,n_obj);
%topOs	= zeros(n_objall,n_obj);
topCs	= class_ids(ids_sort)';
topOs	= obj_ids(ids_sort)';
n_hits	= sum(topCs==repmat(class_ids',1,n_objall),1);
