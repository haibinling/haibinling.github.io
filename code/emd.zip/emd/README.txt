This package containing implementation of EMD for histogram comparision. 
The code is modified from Rubner's code and a matlab interface is implemented.

To compute EMD between two 2D histograms h1, h2, call
	dis = EMD_hist_C( h1, h2, p);
where p = 1 or 2 indicate L1 or L2 ground distance.

To compute EMD between two 3D histograms h1, h2, call
	dis = EMD_hist_3d_C( H1, H2, n1, n2, n3, p);
where [n1,n2,n3]=size(H1) is the size of the histogram.

To use them in unix/linux, use 
	batch_mex
to rebuild the libs.

Haibin Ling
5/18/06

