#ifndef EMD_HIST_H
#define EMD_HIST_H
/*
emd.c

  An implementation of the Earth Movers Distance.
  Based of the solution for the Transportation problem as described in
  "Introduction to Mathematical Programming" by F. S. Hillier and 
  G. J. Lieberman, McGraw-Hill, 1990.
  
   Copyright (C) 1998 Yossi Rubner
   Computer Science Department, Stanford University
   E-Mail: rubner@cs.stanford.edu   URL: http://vision.stanford.edu/~rubner

	Modified by Haibin Ling for testing on histograms.	Aug. 2005.
*/



#define MAX(a,b)	((a)>(b)?(a):(b))
#define ROUND(x)	((int)((x)+.5))


/*****************************************************************************/
/* DEFINITIONS */
#define MAX_SIG_SIZE   900
#define MAX_ITERATIONS 100
#define INFINITY       1e20
#define EPSILON        1e-6

#define DEBUG_LEVEL 0

/*
DEBUG_LEVEL:
0 = NO MESSAGES
1 = PRINT THE NUMBER OF ITERATIONS AND THE FINAL RESULT
2 = PRINT THE RESULT AFTER EVERY ITERATION
3 = PRINT ALSO THE FLOW AFTER EVERY ITERATION
4 = PRINT A LOT OF INFORMATION (PROBABLY USEFUL ONLY FOR THE AUTHOR)
*/

#define MAX_SIG_SIZE1  (MAX_SIG_SIZE+1)  /* FOR THE POSIBLE DUMMY FEATURE */


typedef struct 
{ 
	int x,y; 
} feature_2d; 


typedef struct
{
  int n;                /* Number of features in the signature */
  feature_2d *Features;  /* Pointer to the features vector */
  double *Weights;      /* Pointer to the weights of the features */
} signature_2d;


typedef struct
{
  int from;             /* Feature number in signature 1 */
  int to;               /* Feature number in signature 2 */
  double amount;        /* Amount of flow from "from" to "to" */
} flow_2d;


/* NEW TYPES DEFINITION */

/* node1_t IS USED FOR SINGLE-LINKED LISTS */
typedef struct node1_t {
	int i;
	double val;
	struct node1_t *Next;
} node1_t;

/* node2_t IS USED FOR DOUBLE-LINKED LISTS */
typedef struct node2_t {
	int i, j;
	double val;
	struct node2_t *NextC;               /* NEXT COLUMN */
	struct node2_t *NextR;               /* NEXT ROW */
} node2_t;


/*****************************************************************************
	EMD between hsitograms
 *****************************************************************************/
double	emd_hist_2d(double* h1, double* h2, int nR, int nC, int norm_type);


/****************************************************************************
	Distance between two feature points (Ground distances)
 ****************************************************************************/
double dist1(feature_2d *F1, feature_2d *F2);		/* L1	*/
double dist2(feature_2d *F1, feature_2d *F2);		/* L2	*/


double emd2(signature_2d *Signature1, signature_2d *Signature2,
	  double (*func)(feature_2d *, feature_2d *),
	  flow_2d *Flow, int *FlowSize);


#endif
