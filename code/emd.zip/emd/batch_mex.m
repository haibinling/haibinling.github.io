mex emd_hist_C.cpp emd_hist.cpp
mex emd_hist_3d_C.cpp emd_hist3d.cpp