#include "mex.h"
#include "matrix.h"
#include "emd_hist.h"


/*-----------------------------------------------------------------------
[dis] = EMD_hist_C( h1, h2, norm_type)
	
input:
	h1, h2		: two histograms
	norm_type	:	1-L1, 2-L2
 ------------------------------------------------------------------------*/

void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
    /* Analyze input data and parameters*/
	double *h1	= mxGetPr(prhs[0]);
	int		nR	= mxGetM(prhs[0]);
	int		nC	= mxGetN(prhs[0]);
	double *h2	= mxGetPr(prhs[1]);
    
	/* which norm to use */
	int norm_type=2;		// L2 as default
	if(nrhs>2) {
		norm_type	= ROUND(*(mxGetPr(prhs[2])));
	}
	//printf("norm_type=%d, nR=%d, nC=%d \n", norm_type, nR, nC);

	/* call emd function */
	double dis = emd_hist_2d(h1, h2, nR, nC, norm_type);
	//printf("norm_type=%d, dis=%lf, nR=%d, nC=%d \n", norm_type, dis, nR, nC);

	/* return */
	mxArray*	pMxD = mxCreateDoubleMatrix(1,1,mxREAL);
	*(mxGetPr(pMxD))	= dis;
	plhs[0]	= pMxD;
}

