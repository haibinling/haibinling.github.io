/*
emd.c

 Last update: 3/14/98
 
  An implementation of the Earth Movers Distance.
  Based of the solution for the Transportation problem as described in
  "Introduction to Mathematical Programming" by F. S. Hillier and 
  G. J. Lieberman, McGraw-Hill, 1990.
  
   Copyright (C) 1998 Yossi Rubner
   Computer Science Department, Stanford University
   E-Mail: rubner@cs.stanford.edu   URL: http://vision.stanford.edu/~rubner

	Modified by Haibin Ling for testing on histograms.	Aug. 2005.
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "emd_hist3d.h"


/***********************************************************************
	DEBUGGING MACROS
 ***********************************************************************/
//#define EMD3D_DEBUG

#ifdef EMD3D_DEBUG
	char *sF="emd_hist3d.log";

	#define	D_PRINTF_INIT(sF) \
	{\
		FILE* pF=fopen(sF,"w");\
		fclose(pF);\
	}

	#define	D_PRINTF_plus(sF,sStr) \
	{\
		FILE* pF=fopen(sF,"a+");\
		fprintf(pF, sStr);\
		fclose(pF);\
	}

	#define	D_PRINTF1_plus(sF,sFormat,v1) \
	{\
		FILE* pF=fopen(sF,"a+");\
		fprintf(pF, sFormat, (v1));\
		fclose(pF);\
	}

	#define	D_PRINTF2_plus(sF,sFormat,v1,v2) \
	{\
		FILE* pF=fopen(sF,"a+");\
		fprintf(pF, sFormat, (v1), (v2));\
		fclose(pF);\
	}

	#define	D_PRINTF3_plus(sF,sFormat,v1,v2,v3) \
	{\
		FILE* pF=fopen(sF,"a+");\
		fprintf(pF, sFormat, (v1), (v2), (v3));\
		fclose(pF);\
	}


#else
	#define	D_PRINTF_INIT(sF) 
	#define	D_PRINTF_plus(sF,sStr) 
	#define	D_PRINTF1_plus(sF,sFormat,v1) 
	#define	D_PRINTF2_plus(sF,sFormat,v1,v2) 
	#define	D_PRINTF3_plus(sF,sFormat,v1,v2,v3) 
#endif


/****************************************************************************
	Distance between two feature points (Ground distances)
 ****************************************************************************/
double dist1(feature_3d *F1, feature_3d *F2)
{
	return fabs(F1->x-F2->x)+fabs(F1->y-F2->y)+fabs(F1->z-F2->z);
}

double dist2(feature_3d *F1, feature_3d *F2)
{
	return sqrt((F1->x-F2->x)*(F1->x-F2->x) + 
				(F1->y-F2->y)*(F1->y-F2->y) + 
				(F1->z-F2->z)*(F1->z-F2->z));
}



/*****************************************************************************
	EMD between hsitograms
 *****************************************************************************/
double	emd_hist_3d(double* h1, double* h2, int n1, int n2, int n3, int norm_type)
{
	/* Prepare the feature indicating the "position" of each bins */
	int	nB	= n1*n2*n3;
	feature_3d	*f1	= new feature_3d[nB];
	feature_3d	*f2	= new feature_3d[nB];
	feature_3d	*ff1,*ff2;
	double	dis=-1;
	double (*dist3d)(feature_3d *, feature_3d *);
	
	int x,y,z;
	ff1	= f1;
	ff2	= f2;
	for(z=0; z<n3; ++z) {
		for(y=0; y<n2; ++y) {
			for(x=0; x<n1; ++x) {
				ff1->x	= x;
				ff1->y	= y;
				ff1->z	= z;
				ff2->x	= x;
				ff2->y	= y;
				ff2->z	= z;
				++ff1;
				++ff2;
			}
		}
	}

	signature_3d s1 = { nB, f1, h1};
	signature_3d s2 = { nB, f2, h2};


	/* L2 or L1 distance	*/
	dist3d	= norm_type==1 ? dist1 : dist2;

	//D_PRINTF_INIT(sF);
	D_PRINTF2_plus(sF, "before emd3: _n1=%d, _n1=%d \n", s1.n, s2.n);


	/* EMD */
	flow_3d *Flow=NULL;
	int *fSize=NULL;
	dis	= emd3(&s1, &s2, dist3d, Flow, fSize);
	//printf("norm_type=%d, dis=%lf\n", norm_type, dis);
	
	/* free memeory */
	delete []f1;
	delete []f2;

	return dis;
}



/*****************************************************************************/

/* GLOBAL VARIABLE DECLARATION */
static int _n1, _n2;                          /* SIGNATURES SIZES */
static double _C[MAX_SIG_SIZE1][MAX_SIG_SIZE1];/* THE COST MATRIX */
static node2_3d_t _X[MAX_SIG_SIZE1*2];            /* THE BASIC VARIABLES VECTOR */

/* VARIABLES TO HANDLE _X EFFICIENTLY */
static node2_3d_t *_EndX, *_EnterX;
static char _IsX[MAX_SIG_SIZE1][MAX_SIG_SIZE1];
static node2_3d_t *_RowsX[MAX_SIG_SIZE1], *_ColsX[MAX_SIG_SIZE1];
static double _maxW;
static double _maxC;

/* DECLARATION OF FUNCTIONS */
static double init(signature_3d *Signature1, signature_3d *Signature2,
				   double (*Dist)(feature_3d *, feature_3d *));
static void findBasicVariables(node1_3d_t *U, node1_3d_t *V);
static int isOptimal(node1_3d_t *U, node1_3d_t *V);
static int findLoop(node2_3d_t **Loop);
static void newSol();
static void russel(double *S, double *D);
static void addBasicVariable(int minI, int minJ, double *S, double *D, 
							 node1_3d_t *PrevUMinI, node1_3d_t *PrevVMinJ,
							 node1_3d_t *UHead);


#if DEBUG_LEVEL > 0
static void printSolution();
#endif


/******************************************************************************
double emd3(signature_3d *Signature1, signature_3d *Signature2,
	  double (*func)(feature_3d *, feature_3d *),
	  flow_3d *Flow, int *FlowSize);

 where
 
  Signature1, Signature2  Pointers to signatures that their distance we want
  to compute.
  Dist       Pointer to the ground distance. i.e. the function that computes
  the distance between two features.
  Flow       (Optional) Pointer to a vector of flow_3d (defined in emd.h) 
  where the resulting flow will be stored. Flow must have n1+n2-1
  elements, where n1 and n2 are the sizes of the two signatures
  respectively.
  If NULL, the flow is not returned.
  FlowSize   (Optional) Pointer to an integer where the number of elements in
  Flow will be stored
  
******************************************************************************/

double emd3(signature_3d *Signature1, signature_3d *Signature2,
	  double (*Dist)(feature_3d *, feature_3d *),
	  flow_3d *Flow, int *FlowSize )
{
	int itr;
	double totalCost;
	double w;
	node2_3d_t *XP;
	flow_3d *FlowP;
	node1_3d_t U[MAX_SIG_SIZE1], V[MAX_SIG_SIZE1];
	
	w = init(Signature1, Signature2, Dist);
	
#if DEBUG_LEVEL > 1
	printf("\nINITIAL SOLUTION:\n");
	printSolution();
#endif
	
	D_PRINTF2_plus(sF, "after init: _n1=%d, _n2=%d, ", _n1, _n2);
	D_PRINTF2_plus(sF, "\t_n1=%d, _n2=%d \n", Signature1->n, Signature2->n);

	if (_n1 > 1 && _n2 > 1)  /* IF _n1 = 1 OR _n2 = 1 THEN WE ARE DONE */
    {
		for (itr = 1; itr < MAX_ITERATIONS; itr++)
		{
			/* FIND BASIC VARIABLES */
			D_PRINTF1_plus(sF, "\nbefore findBasicVariables, itr=%d \n", itr);
			findBasicVariables(U, V);
			D_PRINTF1_plus(sF, "ITERATION # %d \n", itr);
			
			/* CHECK FOR OPTIMALITY */
			if (isOptimal(U, V))
				break;
			D_PRINTF1_plus(sF, "ITERATION # %d \n", itr);
			
			/* IMPROVE SOLUTION */
			newSol();
			D_PRINTF1_plus(sF, "ITERATION # %d \n", itr);
			
#if DEBUG_LEVEL > 1
			printf("\nITERATION # %d \n", itr);
			D_PRINTF1_plus(sF, "\nITERATION # %d \n", itr);
			printSolution();
#endif
		}
		
		if (itr == MAX_ITERATIONS)
			fprintf(stderr, "emd: Maximum number of iterations has been reached (%d)\n",
			MAX_ITERATIONS);
    }

	/* COMPUTE THE TOTAL FLOW */
	totalCost = 0;
	if (Flow != NULL)
		FlowP = Flow;
	for(XP=_X; XP < _EndX; XP++)
    {
		if (XP == _EnterX)  /* _EnterX IS THE EMPTY SLOT */
			continue;
		if (XP->i == Signature1->n || XP->j == Signature2->n)  /* DUMMY FEATURE */
			continue;
		
		if (XP->val == 0)  /* ZERO FLOW */
			continue;
		
		totalCost += (double)XP->val * _C[XP->i][XP->j];
		if (Flow != NULL)
		{
			FlowP->from = XP->i;
			FlowP->to = XP->j;
			FlowP->amount = XP->val;
			FlowP++;
		}
    }
	if (Flow != NULL)
		*FlowSize = FlowP-Flow;

	
	D_PRINTF2_plus(sF, "end with itr=%d, dis=%lf\n\n\n", itr, ((double)(totalCost / w)));
	

#if DEBUG_LEVEL > 0
	printf("\n*** OPTIMAL SOLUTION (%d ITERATIONS): %f ***\n", itr, totalCost);
#endif
	
	/* RETURN THE NORMALIZED COST == EMD */
	return (double)(totalCost / w);
}





/**********************
init
**********************/
static double init(signature_3d *Signature1, signature_3d *Signature2, 
				   double (*Dist)(feature_3d *, feature_3d *))
{
	int i, j;
	double sSum, dSum, diff;
	feature_3d *P1, *P2;
	double S[MAX_SIG_SIZE1], D[MAX_SIG_SIZE1];
	
	_n1 = Signature1->n;
	_n2 = Signature2->n;
	
	if (_n1 > MAX_SIG_SIZE || _n2 > MAX_SIG_SIZE)
    {
		fprintf(stderr, "emd: Signature size is limited to %d\n", MAX_SIG_SIZE);
		exit(1);
    }
	
	/* COMPUTE THE DISTANCE MATRIX */
	_maxC = 0;
	for(i=0, P1=Signature1->Features; i < _n1; i++, P1++)
		for(j=0, P2=Signature2->Features; j < _n2; j++, P2++) 
		{
			_C[i][j] = Dist(P1, P2);
			if (_C[i][j] > _maxC)
				_maxC = _C[i][j];
		}
		
	/* SUM UP THE SUPPLY AND DEMAND */
	sSum = 0.0;
	for(i=0; i < _n1; i++)
	{
		S[i] = Signature1->Weights[i];
		sSum += Signature1->Weights[i];
		_RowsX[i] = NULL;
	}
	dSum = 0.0;
	for(j=0; j < _n2; j++)
	{
		D[j] = Signature2->Weights[j];
		dSum += Signature2->Weights[j];
		_ColsX[j] = NULL;
	}
	
	/* IF SUPPLY DIFFERENT THAN THE DEMAND, ADD A ZERO-COST DUMMY CLUSTER */
	diff = sSum - dSum;
	if (fabs(diff) >= EPSILON * sSum)
	{
		if (diff < 0.0)
		{
			for (j=0; j < _n2; j++)
				_C[_n1][j] = 0;
			S[_n1] = -diff;
			_RowsX[_n1] = NULL;
			_n1++;
		}
		else
		{
			for (i=0; i < _n1; i++)
				_C[i][_n2] = 0;
			D[_n2] = diff;
			_ColsX[_n2] = NULL;
			_n2++;
		}
	}
	
	/* INITIALIZE THE BASIC VARIABLE STRUCTURES */
	for (i=0; i < _n1; i++)
		for (j=0; j < _n2; j++)
			_IsX[i][j] = 0;

	_EndX = _X;
		
	_maxW = sSum > dSum ? sSum : dSum;
		
	/* FIND INITIAL SOLUTION */
	russel(S, D);
		
	_EnterX = _EndX++;  /* AN EMPTY SLOT (ONLY _n1+_n2-1 BASIC VARIABLES) */
		
	return sSum > dSum ? dSum : sSum;
}


/**********************
findBasicVariables
**********************/
static void findBasicVariables(node1_3d_t *U, node1_3d_t *V)
{
	int i, j, found;
	int UfoundNum, VfoundNum;
	node1_3d_t u0Head, u1Head, *CurU, *PrevU;
	node1_3d_t v0Head, v1Head, *CurV, *PrevV;
	
	/* INITIALIZE THE ROWS LIST (U) AND THE COLUMNS LIST (V) */
	u0Head.Next = CurU = U;
	for (i=0; i < _n1; i++)
    {
		CurU->i = i;
		CurU->Next = CurU+1;
		CurU++;
    }
	(--CurU)->Next = NULL;
	u1Head.Next = NULL;
	
	CurV = V+1;
	v0Head.Next = _n2 > 1 ? V+1 : NULL;
	for (j=1; j < _n2; j++)
    {
		CurV->i = j;
		CurV->Next = CurV+1;
		CurV++;
    }
	(--CurV)->Next = NULL;
	v1Head.Next = NULL;
	
	/* THERE ARE _n1+_n2 VARIABLES BUT ONLY _n1+_n2-1 INDEPENDENT EQUATIONS,
	SO SET V[0]=0 */
	V[0].i = 0;
	V[0].val = 0;
	v1Head.Next = V;
	v1Head.Next->Next = NULL;
	
	/* LOOP UNTIL ALL VARIABLES ARE FOUND */
	UfoundNum=VfoundNum=0;
	while (UfoundNum < _n1 || VfoundNum < _n2)
    {
		
#if DEBUG_LEVEL > 3
		printf("UfoundNum=%d/%d,VfoundNum=%d/%d\n",UfoundNum,_n1,VfoundNum,_n2);
		printf("U0=");
		for(CurU = u0Head.Next; CurU != NULL; CurU = CurU->Next)
			printf("[%d]",CurU-U);
		printf("\n");
		printf("U1=");
		for(CurU = u1Head.Next; CurU != NULL; CurU = CurU->Next)
			printf("[%d]",CurU-U);
		printf("\n");
		printf("V0=");
		for(CurV = v0Head.Next; CurV != NULL; CurV = CurV->Next)
			printf("[%d]",CurV-V);
		printf("\n");
		printf("V1=");
		for(CurV = v1Head.Next; CurV != NULL; CurV = CurV->Next)
			printf("[%d]",CurV-V);
		printf("\n\n");
#endif
		
		found = 0;
		if (VfoundNum < _n2)
		{
			/* LOOP OVER ALL MARKED COLUMNS */
			PrevV = &v1Head;
			for (CurV=v1Head.Next; CurV != NULL; CurV=CurV->Next)
			{
				j = CurV->i;
				/* FIND THE VARIABLES IN COLUMN j */
				PrevU = &u0Head;
				for (CurU=u0Head.Next; CurU != NULL; CurU=CurU->Next)
				{
					i = CurU->i;
					if (_IsX[i][j])
					{
						/* COMPUTE U[i] */
						CurU->val = _C[i][j] - CurV->val;
						/* ...AND ADD IT TO THE MARKED LIST */
						PrevU->Next = CurU->Next;
						CurU->Next = u1Head.Next != NULL ? u1Head.Next : NULL;
						u1Head.Next = CurU;
						CurU = PrevU;
					}
					else
						PrevU = CurU;
				}
				PrevV->Next = CurV->Next;
				VfoundNum++;
				found = 1;
			}
		}
		if (UfoundNum < _n1)
		{
			/* LOOP OVER ALL MARKED ROWS */
			PrevU = &u1Head;
			for (CurU=u1Head.Next; CurU != NULL; CurU=CurU->Next)
			{
				i = CurU->i;
				/* FIND THE VARIABLES IN ROWS i */
				PrevV = &v0Head;
				for (CurV=v0Head.Next; CurV != NULL; CurV=CurV->Next)
				{
					j = CurV->i;
					if (_IsX[i][j])
					{
						/* COMPUTE V[j] */
						CurV->val = _C[i][j] - CurU->val;
						/* ...AND ADD IT TO THE MARKED LIST */
						PrevV->Next = CurV->Next;
						CurV->Next = v1Head.Next != NULL ? v1Head.Next: NULL;
						v1Head.Next = CurV;
						CurV = PrevV;
					}
					else
						PrevV = CurV;
				}
				PrevU->Next = CurU->Next;
				UfoundNum++;
				found = 1;
			}
		}
		if (! found)
		{
			fprintf(stderr, "emd: Unexpected error in findBasicVariables!\n");
			fprintf(stderr, "This typically happens when the EPSILON defined in\n");
			fprintf(stderr, "emd.h is not right for the scale of the problem.\n");
			exit(1);
		}
    }
}




/**********************
isOptimal
**********************/
static int isOptimal(node1_3d_t *U, node1_3d_t *V)
{    
	double delta, deltaMin;
	int i, j, minI, minJ;
	
	/* FIND THE MINIMAL Cij-Ui-Vj OVER ALL i,j */
	deltaMin = INFINITY;
	for(i=0; i < _n1; i++) {
		for(j=0; j < _n2; j++) {
			if (! _IsX[i][j])
			{
				delta = _C[i][j] - U[i].val - V[j].val;
				if (deltaMin > delta)
				{
					deltaMin = delta;
					minI = i;
					minJ = j;
				}
			}
		}
	}	

#if DEBUG_LEVEL > 3
	printf("deltaMin=%f\n", deltaMin);
#endif
	
	if (deltaMin == INFINITY)
	{
		fprintf(stderr, "emd: Unexpected error in isOptimal.\n");
		exit(0);
	}
	
	_EnterX->i = minI;
	_EnterX->j = minJ;
	
	/* IF NO NEGATIVE deltaMin, WE FOUND THE OPTIMAL SOLUTION */
	return deltaMin >= -EPSILON * _maxC;
	
	/*
	return deltaMin >= -EPSILON;
	*/
}


/**********************
newSol
**********************/
static void newSol()
{
    int i, j, k;
    double xMin;
    int steps;
    node2_3d_t *Loop[2*MAX_SIG_SIZE1], *CurX, *LeaveX;
	
#if DEBUG_LEVEL > 3
    printf("EnterX = (%d,%d)\n", _EnterX->i, _EnterX->j);
#endif
	
    /* ENTER THE NEW BASIC VARIABLE */
    i = _EnterX->i;
    j = _EnterX->j;
    _IsX[i][j] = 1;
    _EnterX->NextC = _RowsX[i];
    _EnterX->NextR = _ColsX[j];
    _EnterX->val = 0;
    _RowsX[i] = _EnterX;
    _ColsX[j] = _EnterX;
	
    /* FIND A CHAIN REACTION */
    steps = findLoop(Loop);
	
    /* FIND THE LARGEST VALUE IN THE LOOP */
    xMin = INFINITY;
    for (k=1; k < steps; k+=2)
	{
		if (Loop[k]->val < xMin)
		{
			LeaveX = Loop[k];
			xMin = Loop[k]->val;
		}
	}
	
    /* UPDATE THE LOOP */
    for (k=0; k < steps; k+=2)
	{
		Loop[k]->val += xMin;
		Loop[k+1]->val -= xMin;
	}
	
#if DEBUG_LEVEL > 3
    printf("LeaveX = (%d,%d)\n", LeaveX->i, LeaveX->j);
#endif
	
    /* REMOVE THE LEAVING BASIC VARIABLE */
    i = LeaveX->i;
    j = LeaveX->j;
    _IsX[i][j] = 0;
    if (_RowsX[i] == LeaveX)
		_RowsX[i] = LeaveX->NextC;
    else
		for (CurX=_RowsX[i]; CurX != NULL; CurX = CurX->NextC)
			if (CurX->NextC == LeaveX)
			{
				CurX->NextC = CurX->NextC->NextC;
				break;
			}

	if (_ColsX[j] == LeaveX)
		_ColsX[j] = LeaveX->NextR;
	else
		for (CurX=_ColsX[j]; CurX != NULL; CurX = CurX->NextR)
			if (CurX->NextR == LeaveX)
			{
				CurX->NextR = CurX->NextR->NextR;
				break;
			}
			
	/* SET _EnterX TO BE THE NEW EMPTY SLOT */
	_EnterX = LeaveX;
}



/**********************
findLoop
**********************/
static int findLoop(node2_3d_t **Loop)
{
	int i, steps;
	node2_3d_t **CurX, *NewX;
	char IsUsed[2*MAX_SIG_SIZE1]; 
	
	for (i=0; i < _n1+_n2; i++)
		IsUsed[i] = 0;
	
	CurX = Loop;
	NewX = *CurX = _EnterX;
	IsUsed[_EnterX-_X] = 1;
	steps = 1;
	
	do
    {
		if (steps%2 == 1)
		{
			/* FIND AN UNUSED X IN THE ROW */
			NewX = _RowsX[NewX->i];
			while (NewX != NULL && IsUsed[NewX-_X])
				NewX = NewX->NextC;
		}
		else
		{
			/* FIND AN UNUSED X IN THE COLUMN, OR THE ENTERING X */
			NewX = _ColsX[NewX->j];
			while (NewX != NULL && IsUsed[NewX-_X] && NewX != _EnterX)
				NewX = NewX->NextR;
			if (NewX == _EnterX)
				break;
		}
		
		if (NewX != NULL)  /* FOUND THE NEXT X */
		{
			/* ADD X TO THE LOOP */
			*++CurX = NewX;
			IsUsed[NewX-_X] = 1;
			steps++;
#if DEBUG_LEVEL > 3
			printf("steps=%d, NewX=(%d,%d)\n", steps, NewX->i, NewX->j);    
#endif
		}
		else  /* DIDN'T FIND THE NEXT X */
		{
			/* BACKTRACK */
			do
			{
				NewX = *CurX;
				do 
				{
					if (steps%2 == 1)
						NewX = NewX->NextR;
					else
						NewX = NewX->NextC;
				} while (NewX != NULL && IsUsed[NewX-_X]);
				
				if (NewX == NULL)
				{
					IsUsed[*CurX-_X] = 0;
					CurX--;
					steps--;
				}
			} while (NewX == NULL && CurX >= Loop);
			
#if DEBUG_LEVEL > 3
			printf("BACKTRACKING TO: steps=%d, NewX=(%d,%d)\n",
				steps, NewX->i, NewX->j);    
#endif
			IsUsed[*CurX-_X] = 0;
			*CurX = NewX;
			IsUsed[NewX-_X] = 1;
		}     
    } while(CurX >= Loop);
	
	if (CurX == Loop)
    {
		fprintf(stderr, "emd: Unexpected error in findLoop!\n");
		exit(1);
    }
#if DEBUG_LEVEL > 3
	printf("FOUND LOOP:\n");
	for (i=0; i < steps; i++)
		printf("%d: (%d,%d)\n", i, Loop[i]->i, Loop[i]->j);
#endif
	
	return steps;
}



/**********************
russel
**********************/
static void russel(double *S, double *D)
{
	int i, j, found, minI, minJ;
	double deltaMin, oldVal, diff;
	double Delta[MAX_SIG_SIZE1][MAX_SIG_SIZE1];
	node1_3d_t Ur[MAX_SIG_SIZE1], Vr[MAX_SIG_SIZE1];
	node1_3d_t uHead, *CurU, *PrevU;
	node1_3d_t vHead, *CurV, *PrevV;
	node1_3d_t *PrevUMinI, *PrevVMinJ, *Remember;
	
	/* INITIALIZE THE ROWS LIST (Ur), AND THE COLUMNS LIST (Vr) */
	uHead.Next = CurU = Ur;
	for (i=0; i < _n1; i++)
    {
		CurU->i = i;
		CurU->val = -INFINITY;
		CurU->Next = CurU+1;
		CurU++;
    }
	(--CurU)->Next = NULL;
	
	vHead.Next = CurV = Vr;
	for (j=0; j < _n2; j++)
    {
		CurV->i = j;
		CurV->val = -INFINITY;
		CurV->Next = CurV+1;
		CurV++;
    }
	(--CurV)->Next = NULL;
	
	/* FIND THE MAXIMUM ROW AND COLUMN VALUES (Ur[i] AND Vr[j]) */
	for(i=0; i < _n1 ; i++)
		for(j=0; j < _n2 ; j++)
		{
			double v;
			v = _C[i][j];
			if (Ur[i].val <= v)
				Ur[i].val = v;
			if (Vr[j].val <= v)
				Vr[j].val = v;
		}
		
	/* COMPUTE THE Delta MATRIX */
	for(i=0; i < _n1 ; i++)
		for(j=0; j < _n2 ; j++)
			Delta[i][j] = _C[i][j] - Ur[i].val - Vr[j].val;
		
	/* FIND THE BASIC VARIABLES */
	do
	{
#if DEBUG_LEVEL > 3
		printf("Ur=");
		for(CurU = uHead.Next; CurU != NULL; CurU = CurU->Next)
			printf("[%d]",CurU-Ur);
		printf("\n");
		printf("Vr=");
		for(CurV = vHead.Next; CurV != NULL; CurV = CurV->Next)
			printf("[%d]",CurV-Vr);
		printf("\n");
		printf("\n\n");
#endif
		
		/* FIND THE SMALLEST Delta[i][j] */
		found = 0; 
		deltaMin = INFINITY;      
		PrevU = &uHead;
		for (CurU=uHead.Next; CurU != NULL; CurU=CurU->Next)
		{
			int i;
			i = CurU->i;
			PrevV = &vHead;
			for (CurV=vHead.Next; CurV != NULL; CurV=CurV->Next)
			{
				int j;
				j = CurV->i;
				if (deltaMin > Delta[i][j])
				{
					deltaMin = Delta[i][j];
					minI = i;
					minJ = j;
					PrevUMinI = PrevU;
					PrevVMinJ = PrevV;
					found = 1;
				}
				PrevV = CurV;
			}
			PrevU = CurU;
		}
		
		if (! found)
			break;
		
		/* ADD X[minI][minJ] TO THE BASIS, AND ADJUST SUPPLIES AND COST */
		Remember = PrevUMinI->Next;
		addBasicVariable(minI, minJ, S, D, PrevUMinI, PrevVMinJ, &uHead);
		
		/* UPDATE THE NECESSARY Delta[][] */
		if (Remember == PrevUMinI->Next)  /* LINE minI WAS DELETED */
		{
			for (CurV=vHead.Next; CurV != NULL; CurV=CurV->Next)
			{
				int j;
				j = CurV->i;
				if (CurV->val == _C[minI][j])  /* COLUMN j NEEDS UPDATING */
				{
					/* FIND THE NEW MAXIMUM VALUE IN THE COLUMN */
					oldVal = CurV->val;
					CurV->val = -INFINITY;
					for (CurU=uHead.Next; CurU != NULL; CurU=CurU->Next)
					{
						int i;
						i = CurU->i;
						if (CurV->val <= _C[i][j])
							CurV->val = _C[i][j];
					}
					
					/* IF NEEDED, ADJUST THE RELEVANT Delta[*][j] */
					diff = oldVal - CurV->val;
					if (fabs(diff) < EPSILON * _maxC)
						for (CurU=uHead.Next; CurU != NULL; CurU=CurU->Next)
							Delta[CurU->i][j] += diff;
				}
			}
		}
		else  /* COLUMN minJ WAS DELETED */
		{
			for (CurU=uHead.Next; CurU != NULL; CurU=CurU->Next)
			{
				int i;
				i = CurU->i;
				if (CurU->val == _C[i][minJ])  /* ROW i NEEDS UPDATING */
				{
					/* FIND THE NEW MAXIMUM VALUE IN THE ROW */
					oldVal = CurU->val;
					CurU->val = -INFINITY;
					for (CurV=vHead.Next; CurV != NULL; CurV=CurV->Next)
					{
						int j;
						j = CurV->i;
						if(CurU->val <= _C[i][j])
							CurU->val = _C[i][j];
					}
					
					/* If NEEDED, ADJUST THE RELEVANT Delta[i][*] */
					diff = oldVal - CurU->val;
					if (fabs(diff) < EPSILON * _maxC)
						for (CurV=vHead.Next; CurV != NULL; CurV=CurV->Next)
							Delta[i][CurV->i] += diff;
				}
			}
		}
    } while (uHead.Next != NULL || vHead.Next != NULL);
}




/**********************
addBasicVariable
**********************/
static void addBasicVariable(int minI, int minJ, double *S, double *D, 
							 node1_3d_t *PrevUMinI, node1_3d_t *PrevVMinJ,
							 node1_3d_t *UHead)
{
	double T;
	
	if (fabs(S[minI]-D[minJ]) <= EPSILON * _maxW)  /* DEGENERATE CASE */
    {
		T = S[minI];
		S[minI] = 0;
		D[minJ] -= T; 
    }
	else if (S[minI] < D[minJ])  /* SUPPLY EXHAUSTED */
    {
		T = S[minI];
		S[minI] = 0;
		D[minJ] -= T; 
    }
	else  /* DEMAND EXHAUSTED */
    {
		T = D[minJ];
		D[minJ] = 0; 
		S[minI] -= T; 
    }
	
	/* X(minI,minJ) IS A BASIC VARIABLE */
	_IsX[minI][minJ] = 1; 
	
	_EndX->val = T;
	_EndX->i = minI;
	_EndX->j = minJ;
	_EndX->NextC = _RowsX[minI];
	_EndX->NextR = _ColsX[minJ];
	_RowsX[minI] = _EndX;
	_ColsX[minJ] = _EndX;
	_EndX++;
	
	/* DELETE SUPPLY ROW ONLY IF THE EMPTY, AND IF NOT LAST ROW */
	if (S[minI] == 0 && UHead->Next->Next != NULL)
		PrevUMinI->Next = PrevUMinI->Next->Next;  /* REMOVE ROW FROM LIST */
	else
		PrevVMinJ->Next = PrevVMinJ->Next->Next;  /* REMOVE COLUMN FROM LIST */
}





/**********************
printSolution
**********************/
static void printSolution()
{
	node2_3d_t *P;
	double totalCost;
	
	totalCost = 0;
	
#if DEBUG_LEVEL > 2
	printf("SIG1\tSIG2\tFLOW\tCOST\n");
#endif
	for(P=_X; P < _EndX; P++)
		if (P != _EnterX && _IsX[P->i][P->j])
		{
#if DEBUG_LEVEL > 2
			printf("%d\t%d\t%f\t%f\n", P->i, P->j, P->val, _C[P->i][P->j]);
#endif
			totalCost += (double)P->val * _C[P->i][P->j];
		}
		
	printf("COST = %f\n", totalCost);
}

