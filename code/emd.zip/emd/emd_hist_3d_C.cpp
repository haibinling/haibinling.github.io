#include "mex.h"
#include "matrix.h"
#include "emd_hist3d.h"


/*-----------------------------------------------------------------------
[dis] = EMD_hist_3d_C( h1, h2, n1, n2, n3, norm_type)
	
input:
	h1, h2		: two histograms
	norm_type	:	1-L1, 2-L2
 ------------------------------------------------------------------------*/

void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
    /* Analyze input data and parameters*/
	double *h1	= mxGetPr(prhs[0]);
	double *h2	= mxGetPr(prhs[1]);
	int		n1	= ROUND(*mxGetPr(prhs[2]));
	int		n2	= ROUND(*mxGetPr(prhs[3]));
	int		n3	= ROUND(*mxGetPr(prhs[4]));
    
	/* which norm to use */
	int norm_type=2;		// L2 as default
	if(nrhs>5) {
		norm_type	= ROUND(*(mxGetPr(prhs[5])));
	}

	/* call emd function */
	double dis = emd_hist_3d(h1, h2, n1, n2, n3, norm_type);
	//printf("norm_type=%d, dis=%lf, nR=%d, nC=%d \n", norm_type, dis, nR, nC);

	/* return */
	mxArray*	pMxD = mxCreateDoubleMatrix(1,1,mxREAL);
	*(mxGetPr(pMxD))	= dis;
	plhs[0]	= pMxD;
}

